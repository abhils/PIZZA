import { PRODUCT_MAP } from '../data/menuData.js';
import { ORDER_RULES } from '../data/config.js';

export const formatINR = (n) => '₹' + Number(n).toLocaleString('en-IN');

/**
 * Turn a stored cart entry ({ productId, size, extraIds, qty }) into a priced line.
 * Prices ALWAYS come from menuData — never from stored or typed values.
 * Returns null if the product/size no longer exists.
 */
export function resolveLine(entry) {
  const product = PRODUCT_MAP[entry.productId];
  if (!product) return null;

  let basePrice = null;
  let sizeName = null;
  if (product.sizes) {
    const s = product.sizes.find((x) => x.name === entry.size);
    if (!s) return null;
    sizeName = s.name;
    basePrice = s.price;
  } else {
    basePrice = typeof product.price === 'number' ? product.price : null;
  }

  const extras = (product.extras || []).filter((e) => (entry.extraIds || []).includes(e.id));
  const priced = basePrice !== null;
  const unitPrice = priced ? basePrice + extras.reduce((sum, e) => sum + e.price, 0) : null;
  const qty = entry.qty;

  return {
    key: entry.key,
    product,
    productId: product.id,
    name: product.name,
    sizeName,
    extras,
    qty,
    priced,
    unitPrice,
    lineTotal: priced ? unitPrice * qty : null,
  };
}

/**
 * Totals for a list of resolved lines.
 * orderType: 'delivery' | 'dinein' | null
 */
export function calcTotals(lines, orderType) {
  const subtotal = lines.reduce((sum, l) => sum + (l.priced ? l.lineTotal : 0), 0);
  const unpricedCount = lines.filter((l) => !l.priced).length;
  const itemCount = lines.reduce((sum, l) => sum + l.qty, 0);
  const isDelivery = orderType === 'delivery';
  const deliveryCharge = isDelivery && lines.length > 0 ? ORDER_RULES.deliveryCharge : 0;
  const meetsMinimum = !isDelivery || subtotal >= ORDER_RULES.deliveryMinimum;
  const shortBy = isDelivery ? Math.max(0, ORDER_RULES.deliveryMinimum - subtotal) : 0;

  return {
    itemCount,
    subtotal,
    unpricedCount,
    hasUnpriced: unpricedCount > 0,
    deliveryCharge,
    knownTotal: subtotal + deliveryCharge,
    meetsMinimum,
    shortBy,
  };
}

/** Price label for a catalogue product (cards). */
export function priceLabel(product) {
  if (product.sizes) {
    const prices = product.sizes.map((s) => s.price);
    return `${formatINR(Math.min(...prices))} – ${formatINR(Math.max(...prices))}`;
  }
  return typeof product.price === 'number' ? formatINR(product.price) : 'MRP';
}
