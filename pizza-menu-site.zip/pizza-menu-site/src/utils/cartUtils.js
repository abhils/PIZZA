import { PRODUCT_MAP } from '../data/menuData.js';

export const STORAGE_KEY = 'pizza-menu-cart-v1';
const MAX_QTY = 50;

/** Same product + size + extras => same cart line. Different options => separate lines. */
export function makeKey(productId, size, extraIds = []) {
  return [productId, size || '-', [...extraIds].sort().join('+') || '-'].join('|');
}

const clampQty = (n) => Math.max(1, Math.min(MAX_QTY, Math.floor(Number(n) || 1)));

export function cartReducer(state, action) {
  switch (action.type) {
    case 'ADD': {
      const { productId, size = null, extraIds = [], qty = 1 } = action;
      const product = PRODUCT_MAP[productId];
      if (!product) return state;
      if (product.sizes && !product.sizes.some((s) => s.name === size)) return state; // size required
      const validExtras = extraIds.filter((id) => (product.extras || []).some((e) => e.id === id));
      const key = makeKey(productId, product.sizes ? size : null, validExtras);
      const existing = state.find((l) => l.key === key);
      if (existing) {
        return state.map((l) => (l.key === key ? { ...l, qty: clampQty(l.qty + qty) } : l));
      }
      return [...state, { key, productId, size: product.sizes ? size : null, extraIds: validExtras, qty: clampQty(qty) }];
    }
    case 'INC':
      return state.map((l) => (l.key === action.key ? { ...l, qty: clampQty(l.qty + 1) } : l));
    case 'DEC':
      return state.flatMap((l) => {
        if (l.key !== action.key) return [l];
        return l.qty <= 1 ? [] : [{ ...l, qty: l.qty - 1 }];
      });
    case 'REMOVE':
      return state.filter((l) => l.key !== action.key);
    case 'CLEAR':
      return [];
    default:
      return state;
  }
}

/** Load + sanitise the persisted cart. Anything unknown/invalid is dropped. */
export function loadCart() {
  try {
    const raw = typeof localStorage !== 'undefined' ? localStorage.getItem(STORAGE_KEY) : null;
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed.flatMap((e) => {
      const product = e && PRODUCT_MAP[e.productId];
      if (!product) return [];
      if (product.sizes && !product.sizes.some((s) => s.name === e.size)) return [];
      const extraIds = (Array.isArray(e.extraIds) ? e.extraIds : []).filter((id) => (product.extras || []).some((x) => x.id === id));
      const size = product.sizes ? e.size : null;
      return [{ key: makeKey(product.id, size, extraIds), productId: product.id, size, extraIds, qty: clampQty(e.qty) }];
    });
  } catch {
    return [];
  }
}

export function saveCart(cart) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(cart));
  } catch {
    /* storage may be unavailable (private mode) — cart still works in memory */
  }
}
