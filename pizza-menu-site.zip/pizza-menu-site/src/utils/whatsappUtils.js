import { BUSINESS, ENQUIRY_MESSAGE } from '../data/config.js';
import { formatINR } from './priceUtils.js';
import { cleanText, normaliseMobile } from './validationUtils.js';

const BASE = `https://wa.me/${BUSINESS.whatsappNumber}`;

export const buildEnquiryUrl = () => `${BASE}?text=${encodeURIComponent(ENQUIRY_MESSAGE)}`;

function itemLines(lines) {
  return lines
    .map((l, i) => {
      const title = l.sizeName ? `${l.name} — ${l.sizeName}` : l.name;
      const out = [`${i + 1}. ${title}`];
      if (l.extras.length) out.push(`   Extras: ${l.extras.map((e) => `${e.name} (+${formatINR(e.price)})`).join(', ')}`);
      out.push(`   Quantity: ${l.qty}`);
      if (l.priced) {
        out.push(`   Unit Price: ${formatINR(l.unitPrice)}`);
        out.push(`   Total: ${formatINR(l.lineTotal)}`);
      } else {
        out.push('   Price: MRP — to be confirmed by restaurant');
      }
      return out.join('\n');
    })
    .join('\n\n');
}

function billLines(totals) {
  const out = [
    '*BILL SUMMARY*',
    `Food Subtotal: ${formatINR(totals.subtotal)}${totals.hasUnpriced ? ' (excludes MRP items)' : ''}`,
    `Delivery Charge: ${formatINR(totals.deliveryCharge)}`,
    'Taxes: Extra, to be confirmed',
    `Known Total: ${formatINR(totals.knownTotal)}${totals.hasUnpriced ? ' (excl. MRP items & taxes)' : ''}`,
  ];
  if (totals.hasUnpriced) out.push('Note: Some items are MRP — please confirm their price in the final bill.');
  return out.join('\n');
}

/** Plain-text WhatsApp message built from the real cart + customer details. */
export function buildOrderMessage({ orderType, details, lines, totals }) {
  const name = cleanText(details.name, 80);
  if (orderType === 'delivery') {
    const mobile = normaliseMobile(details.mobile);
    const instructions = cleanText(details.instructions, 250) || 'None';
    return [
      'Hello! I would like to place a food order.',
      '',
      '*ORDER TYPE: HOME DELIVERY*',
      '',
      '*CUSTOMER DETAILS*',
      `Name: ${name}`,
      `Mobile: ${mobile}`,
      '',
      '*DELIVERY ADDRESS*',
      cleanText(details.address, 250),
      `House/Street/Landmark: ${cleanText(details.landmark, 120)}`,
      `Area/Locality: ${cleanText(details.area, 100)}`,
      `City/Village: ${cleanText(details.city, 100)}`,
      '',
      '*ORDER DETAILS*',
      '',
      itemLines(lines),
      '',
      billLines(totals),
      '',
      `Delivery Instructions: ${instructions}`,
      '',
      'Please confirm the availability, final bill, and expected delivery time.',
      '',
      'Thank you!',
    ].join('\n');
  }

  const mobile = normaliseMobile(details.mobile) || 'Not Provided';
  return [
    'Hello! I would like to place a dine-in order.',
    '',
    '*ORDER TYPE: DINE-IN*',
    '',
    `Customer Name: ${name}`,
    `Table Number: ${cleanText(details.table, 10)}`,
    `Mobile: ${mobile}`,
    '',
    '*ORDER DETAILS*',
    '',
    itemLines(lines),
    '',
    billLines(totals),
    '',
    'Please confirm my order.',
    '',
    'Thank you!',
  ].join('\n');
}

export const buildOrderUrl = (params) => `${BASE}?text=${encodeURIComponent(buildOrderMessage(params))}`;

/**
 * Open a WhatsApp URL from a user click. New tab first; if the browser blocks the
 * popup, fall back to navigating this tab. Returns 'tab' | 'same-tab'.
 */
export function openWhatsApp(url) {
  const w = window.open(url, '_blank', 'noopener,noreferrer');
  if (w) return 'tab';
  window.location.assign(url);
  return 'same-tab';
}
