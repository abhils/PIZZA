import { ORDER_RULES } from '../data/config.js';

/** Trim, collapse whitespace, strip control characters, cap length. */
export function cleanText(value, max = 200) {
  return String(value ?? '')
    .replace(/[\u0000-\u001F\u007F]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, max);
}

/** Returns the bare 10 digits for a valid Indian mobile number, or null. Accepts +91 / 91 / 0 prefixes. */
export function normaliseMobile(value) {
  let digits = String(value ?? '').replace(/\D/g, '');
  if (digits.length === 12 && digits.startsWith('91')) digits = digits.slice(2);
  else if (digits.length === 11 && digits.startsWith('0')) digits = digits.slice(1);
  return /^[6-9]\d{9}$/.test(digits) ? digits : null;
}

export function validateDelivery(d) {
  const e = {};
  if (cleanText(d.name, 80).length < 2) e.name = 'Please enter your full name.';
  if (!normaliseMobile(d.mobile)) e.mobile = 'Enter a valid 10-digit Indian mobile number (starts with 6–9).';
  if (cleanText(d.address, 250).length < 5) e.address = 'Please enter your complete delivery address.';
  if (!cleanText(d.landmark, 120)) e.landmark = 'Please add house number, street or a landmark.';
  if (!cleanText(d.area, 100)) e.area = 'Please enter your area or locality.';
  if (!cleanText(d.city, 100)) e.city = 'Please enter your city or village.';
  return e;
}

export function validateDineIn(d) {
  const e = {};
  if (cleanText(d.name, 80).length < 2) e.name = 'Please enter your name.';
  const table = cleanText(d.table, 10);
  if (!table) e.table = 'Table number is required so we can find your order.';
  else if (!/^[A-Za-z0-9-]{1,10}$/.test(table)) e.table = 'Use only letters, numbers or a hyphen.';
  else if (ORDER_RULES.maxTableNumber && !(Number(table) >= 1 && Number(table) <= ORDER_RULES.maxTableNumber)) {
    e.table = `Enter a table number between 1 and ${ORDER_RULES.maxTableNumber}.`;
  }
  if (d.mobile && cleanText(d.mobile, 20) && !normaliseMobile(d.mobile)) {
    e.mobile = 'Enter a valid 10-digit mobile number, or leave it blank.';
  }
  return e;
}
