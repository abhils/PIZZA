import { Info } from 'lucide-react';
import Field from './Field.jsx';
import { formatINR } from '../utils/priceUtils.js';
import { ORDER_RULES } from '../data/config.js';

export default function DeliveryForm({ id, details, errors, totals, onChange, onSubmit }) {
  const set = (k) => (e) => onChange({ [k]: e.target.value });

  return (
    <form id={id} onSubmit={onSubmit} noValidate className="space-y-4">
      <p className="text-sm text-ink/75">Tell us where to deliver. No location sharing needed.</p>

      {!totals.meetsMinimum && (
        <div role="alert" className="flex items-start gap-2 rounded-xl border border-brand-red/50 bg-brand-red/10 p-3 text-sm font-semibold text-navy">
          <Info className="mt-0.5 h-4 w-4 shrink-0 text-brand-red" aria-hidden="true" />
          <span>
            Minimum order for home delivery is {formatINR(ORDER_RULES.deliveryMinimum)} (food only). Add {formatINR(totals.shortBy)} more to continue, or choose Dine-In.
          </span>
        </div>
      )}

      <div className="grid gap-4 sm:grid-cols-2">
        <Field label="Full Name" required value={details.name} onChange={set('name')} error={errors.name} placeholder="Enter your full name" autoComplete="name" maxLength={80} />
        <Field
          label="Mobile Number"
          required
          type="tel"
          inputMode="numeric"
          autoComplete="tel-national"
          value={details.mobile}
          onChange={set('mobile')}
          error={errors.mobile}
          placeholder="Enter your 10-digit mobile number"
          maxLength={16}
        />
      </div>

      <Field
        label="Complete Delivery Address"
        required
        multiline
        value={details.address}
        onChange={set('address')}
        error={errors.address}
        placeholder="House number, street, village or locality"
        autoComplete="street-address"
        maxLength={250}
      />
      <Field
        label="House Number / Street / Landmark"
        required
        value={details.landmark}
        onChange={set('landmark')}
        error={errors.landmark}
        placeholder="Nearby shop, school or other landmark"
        maxLength={120}
      />
      <div className="grid gap-4 sm:grid-cols-2">
        <Field label="Area or Locality" required value={details.area} onChange={set('area')} error={errors.area} placeholder="Enter your area or locality" maxLength={100} />
        <Field label="City or Village" required value={details.city} onChange={set('city')} error={errors.city} placeholder="Enter your city or village" autoComplete="address-level2" maxLength={100} />
      </div>
      <Field
        label="Additional Delivery Instructions"
        multiline
        value={details.instructions}
        onChange={set('instructions')}
        placeholder="Any special delivery instructions?"
        maxLength={250}
      />
    </form>
  );
}
