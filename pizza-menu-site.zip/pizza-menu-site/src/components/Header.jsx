import { useState } from 'react';
import { Menu, ShoppingCart, X } from 'lucide-react';
import { BUSINESS } from '../data/config.js';
import { useCart } from '../context/CartContext.jsx';
import { BrandMark, InstagramIcon } from './icons.jsx';

export const NAV_LINKS = [
  { label: 'Home', href: '#home' },
  { label: 'Menu', href: '#menu' },
  { label: 'Pizzas', href: '#pizzas' },
  { label: 'Burgers', href: '#burgers' },
  { label: 'Pasta', href: '#pastas' },
  { label: 'Beverages', href: '#shakes' },
  { label: 'Contact', href: '#contact' },
];

export default function Header({ onOpenCart, onOrderNow }) {
  const { count, bump } = useCart();
  const [open, setOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 border-b border-gold/70 bg-ivory/95 backdrop-blur">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between gap-3 px-4">
        <a href="#home" className="flex min-w-0 items-center gap-2.5" aria-label={`${BUSINESS.brandName} — home`}>
          <BrandMark className="h-10 w-10 shrink-0" />
          <span className="min-w-0 leading-tight">
            <span className="block truncate font-display text-base font-extrabold text-navy sm:text-lg">{BUSINESS.brandName}</span>
            <span className="hidden text-xs font-medium text-ink/70 sm:block">{BUSINESS.brandTagline}</span>
          </span>
        </a>

        <nav aria-label="Primary" className="hidden items-center gap-1 lg:flex">
          {NAV_LINKS.map((l) => (
            <a key={l.href} href={l.href} className="rounded-full px-3 py-2 text-sm font-semibold text-navy transition hover:bg-cream hover:text-brand-red">
              {l.label}
            </a>
          ))}
        </nav>

        <div className="flex items-center gap-2">
          <a
            href={BUSINESS.instagramUrl}
            target="_blank"
            rel="noopener noreferrer"
            aria-label={`Instagram ${BUSINESS.instagramHandle} (opens in a new tab)`}
            className="hidden h-11 w-11 place-items-center rounded-full border border-gold bg-white text-navy transition hover:bg-cream sm:grid"
          >
            <InstagramIcon className="h-5 w-5" />
          </a>

          <button
            type="button"
            onClick={onOpenCart}
            aria-label={`Open cart, ${count} item${count === 1 ? '' : 's'}`}
            className="relative grid h-11 w-11 place-items-center rounded-full border border-gold bg-white text-navy transition hover:bg-cream"
          >
            <ShoppingCart className="h-5 w-5" />
            {count > 0 && (
              <span
                key={bump}
                className="badge-pop absolute -right-1 -top-1 grid h-5 min-w-5 place-items-center rounded-full bg-brand-red px-1 text-[11px] font-bold text-white"
              >
                {count}
              </span>
            )}
          </button>

          <button
            type="button"
            onClick={onOrderNow}
            className="hidden h-11 rounded-full bg-brand-red px-5 text-sm font-bold text-white shadow-sm transition hover:bg-brand-red-dark sm:block"
          >
            Order Now
          </button>

          <button
            type="button"
            onClick={() => setOpen((v) => !v)}
            aria-expanded={open}
            aria-controls="mobile-nav"
            aria-label={open ? 'Close menu' : 'Open menu'}
            className="grid h-11 w-11 place-items-center rounded-full border border-gold bg-white text-navy lg:hidden"
          >
            {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </div>

      {open && (
        <nav id="mobile-nav" aria-label="Mobile" className="border-t border-gold/60 bg-ivory px-4 pb-4 pt-2 lg:hidden">
          <ul className="grid grid-cols-2 gap-2">
            {NAV_LINKS.map((l) => (
              <li key={l.href}>
                <a
                  href={l.href}
                  onClick={() => setOpen(false)}
                  className="block rounded-xl border border-gold/60 bg-white px-4 py-3 text-center text-sm font-bold text-navy"
                >
                  {l.label}
                </a>
              </li>
            ))}
          </ul>
          <div className="mt-3 flex gap-2">
            <button
              type="button"
              onClick={() => {
                setOpen(false);
                onOrderNow();
              }}
              className="h-12 flex-1 rounded-xl bg-brand-red text-sm font-bold text-white"
            >
              Order Now
            </button>
            <a
              href={BUSINESS.instagramUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="grid h-12 flex-1 place-items-center rounded-xl border border-gold bg-white text-sm font-bold text-navy"
            >
              <span className="flex items-center gap-2">
                <InstagramIcon className="h-4 w-4" /> Instagram
              </span>
            </a>
          </div>
        </nav>
      )}
    </header>
  );
}
