// Brand icons drawn inline so no extra package or network request is needed.

export function WhatsAppIcon({ className = 'h-6 w-6', ...rest }) {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" className={className} aria-hidden="true" {...rest}>
      <path d="M12.04 2C6.58 2 2.13 6.45 2.13 11.91c0 1.75.46 3.45 1.32 4.95L2.05 22l5.25-1.38a9.9 9.9 0 0 0 4.74 1.21h.01c5.46 0 9.91-4.45 9.91-9.91 0-2.65-1.03-5.14-2.9-7.01A9.82 9.82 0 0 0 12.04 2Zm0 18.15h-.01a8.2 8.2 0 0 1-4.18-1.15l-.3-.18-3.12.82.83-3.04-.2-.31a8.2 8.2 0 0 1-1.26-4.38c0-4.54 3.7-8.23 8.24-8.23 2.2 0 4.27.86 5.82 2.42a8.18 8.18 0 0 1 2.41 5.83c0 4.54-3.7 8.22-8.23 8.22Zm4.52-6.16c-.25-.12-1.47-.72-1.69-.81-.23-.08-.39-.12-.56.12-.17.25-.64.81-.78.97-.14.17-.29.19-.54.06-.25-.12-1.05-.39-2-1.23-.74-.66-1.23-1.47-1.38-1.72-.14-.25-.02-.38.11-.5.11-.11.25-.29.37-.43.12-.14.17-.25.25-.41.08-.17.04-.31-.02-.43-.06-.12-.56-1.34-.76-1.84-.2-.48-.41-.42-.56-.43h-.48c-.17 0-.43.06-.66.31-.23.25-.87.85-.87 2.07s.89 2.4 1.01 2.56c.12.17 1.75 2.67 4.23 3.74.59.26 1.05.41 1.41.52.59.19 1.13.16 1.56.1.48-.07 1.47-.6 1.67-1.18.21-.58.21-1.07.14-1.18-.06-.1-.23-.16-.48-.29Z" />
    </svg>
  );
}

export function InstagramIcon({ className = 'h-6 w-6', ...rest }) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      aria-hidden="true"
      {...rest}
    >
      <rect x="3" y="3" width="18" height="18" rx="5" />
      <circle cx="12" cy="12" r="4" />
      <circle cx="17.5" cy="6.5" r="1" fill="currentColor" stroke="none" />
    </svg>
  );
}

/** Neutral pizza-slice brand mark (replace with the restaurant's logo when available). */
export function BrandMark({ className = 'h-10 w-10' }) {
  return (
    <svg viewBox="0 0 64 64" className={className} aria-hidden="true">
      <rect width="64" height="64" rx="14" fill="#071B33" />
      <path d="M12 20 Q32 8 52 20 L32 54 Z" fill="#DDBB79" />
      <path d="M15 23 Q32 13 49 23 L32 51 Z" fill="#F4C542" />
      <circle cx="26" cy="27" r="3.4" fill="#E7192D" />
      <circle cx="38" cy="28" r="3.4" fill="#E7192D" />
      <circle cx="32" cy="38" r="3.2" fill="#176B3A" />
    </svg>
  );
}

/** Veg marker: green-bordered square + dot AND a text label, so colour isn't the only signal. */
export function VegBadge({ className = '' }) {
  return (
    <span className={`inline-flex items-center gap-1 text-[11px] font-bold text-forest ${className}`} title="Vegetarian">
      <span className="grid h-4 w-4 place-items-center rounded-[3px] border-2 border-forest bg-white" aria-hidden="true">
        <span className="h-2 w-2 rounded-full bg-forest" />
      </span>
      Veg
    </span>
  );
}
