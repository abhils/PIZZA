import { BUSINESS, ORDER_RULES } from '../data/config.js';
import { BrandMark, InstagramIcon, WhatsAppIcon } from './icons.jsx';
import { NAV_LINKS } from './Header.jsx';
import { buildEnquiryUrl } from '../utils/whatsappUtils.js';

export default function Footer() {
  return (
    <footer id="contact" className="scroll-mt-20 bg-navy text-ivory">
      <div className="mx-auto grid max-w-7xl gap-8 px-4 py-12 sm:grid-cols-2 lg:grid-cols-4">
        <div>
          <div className="flex items-center gap-3">
            <BrandMark className="h-12 w-12" />
            <p className="font-display text-lg font-extrabold">{BUSINESS.brandName}</p>
          </div>
          <p className="mt-3 text-sm text-ivory/80">Pizzas, burgers, pasta, fries, shakes and more — browse the menu and order through WhatsApp.</p>
        </div>

        <div>
          <h2 className="font-display text-base font-extrabold text-gold">Quick Links</h2>
          <ul className="mt-3 space-y-1.5 text-sm">
            {NAV_LINKS.map((l) => (
              <li key={l.href}>
                <a href={l.href} className="inline-block py-1 text-ivory/85 hover:text-white hover:underline">
                  {l.label}
                </a>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h2 className="font-display text-base font-extrabold text-gold">Contact</h2>
          <ul className="mt-3 space-y-3 text-sm">
            <li>
              <a href={buildEnquiryUrl()} target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 hover:underline">
                <WhatsAppIcon className="h-5 w-5 text-[#25D366]" /> WhatsApp: {BUSINESS.whatsappDisplay}
              </a>
            </li>
            <li>
              <a href={BUSINESS.instagramUrl} target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 hover:underline">
                <InstagramIcon className="h-5 w-5" /> Instagram: {BUSINESS.instagramHandle}
              </a>
            </li>
          </ul>
        </div>

        <div>
          <h2 className="font-display text-base font-extrabold text-gold">Ordering Information</h2>
          <ul className="mt-3 space-y-1.5 text-sm text-ivory/85">
            <li>Minimum home delivery order: ₹{ORDER_RULES.deliveryMinimum}</li>
            <li>Home delivery charge: ₹{ORDER_RULES.deliveryCharge} per order</li>
            <li>Last home delivery order: {ORDER_RULES.lastDeliveryOrderTime}</li>
            <li>Taxes extra</li>
            {ORDER_RULES.openingHours && <li>Hours: {ORDER_RULES.openingHours}</li>}
          </ul>
        </div>
      </div>

      <div className="border-t border-white/15">
        <div className="mx-auto flex max-w-7xl flex-col gap-1 px-4 py-5 text-sm text-ivory/75 sm:flex-row sm:justify-between">
          <p>{BUSINESS.copyright}</p>
          <p>{BUSINESS.supportCredit}</p>
        </div>
      </div>
    </footer>
  );
}
