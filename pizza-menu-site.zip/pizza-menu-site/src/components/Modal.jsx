import { useEffect, useRef } from 'react';
import { X } from 'lucide-react';

const FOCUSABLE =
  'a[href],button:not([disabled]),textarea:not([disabled]),input:not([disabled]),select:not([disabled]),[tabindex]:not([tabindex="-1"])';

/**
 * Accessible dialog: Escape closes, focus is trapped and restored, background scroll is locked.
 * variant="center" (checkout) or "drawer" (cart). Body scrolls; `footer` stays pinned.
 */
export default function Modal({ title, titleId, onClose, children, footer, variant = 'center', closeLabel = 'Close' }) {
  const panelRef = useRef(null);
  const onCloseRef = useRef(onClose);
  onCloseRef.current = onClose;

  useEffect(() => {
    const previouslyFocused = document.activeElement;
    const prevOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';

    const panel = panelRef.current;
    const first = panel.querySelector('[data-autofocus]') || panel.querySelector(FOCUSABLE);
    first?.focus();

    const onKey = (e) => {
      if (e.key === 'Escape') {
        e.stopPropagation();
        onCloseRef.current();
        return;
      }
      if (e.key !== 'Tab') return;
      const nodes = [...panel.querySelectorAll(FOCUSABLE)].filter((n) => n.offsetParent !== null);
      if (!nodes.length) return;
      const firstEl = nodes[0];
      const lastEl = nodes[nodes.length - 1];
      if (e.shiftKey && document.activeElement === firstEl) {
        e.preventDefault();
        lastEl.focus();
      } else if (!e.shiftKey && document.activeElement === lastEl) {
        e.preventDefault();
        firstEl.focus();
      }
    };
    document.addEventListener('keydown', onKey);
    return () => {
      document.removeEventListener('keydown', onKey);
      document.body.style.overflow = prevOverflow;
      if (previouslyFocused instanceof HTMLElement) previouslyFocused.focus();
    };
  }, []);

  const isDrawer = variant === 'drawer';
  return (
    <div className={`fixed inset-0 z-[60] flex ${isDrawer ? 'justify-end' : 'items-end justify-center sm:items-center sm:p-4'}`}>
      <div className="anim-fade absolute inset-0 bg-navy/60 backdrop-blur-[2px]" onClick={onClose} aria-hidden="true" />
      <div
        ref={panelRef}
        role="dialog"
        aria-modal="true"
        aria-labelledby={titleId}
        className={`relative flex max-h-[100dvh] w-full flex-col border border-gold bg-ivory shadow-2xl ${
          isDrawer
            ? 'anim-drawer h-[100dvh] max-w-md'
            : 'anim-modal max-h-[94dvh] max-w-2xl rounded-t-3xl sm:rounded-3xl'
        }`}
      >
        <div className="flex items-start justify-between gap-3 border-b border-gold/60 px-5 py-4">
          <h2 id={titleId} className="font-display text-xl font-extrabold text-navy sm:text-2xl">
            {title}
          </h2>
          <button
            type="button"
            onClick={onClose}
            aria-label={closeLabel}
            className="grid h-10 w-10 shrink-0 place-items-center rounded-full border border-gold bg-white text-navy transition hover:bg-cream"
          >
            <X className="h-5 w-5" />
          </button>
        </div>
        <div className="min-h-0 flex-1 overflow-y-auto overscroll-contain px-5 py-5">{children}</div>
        {footer && <div className="border-t border-gold/60 bg-cream/70 px-5 py-4 pb-[max(1rem,env(safe-area-inset-bottom))]">{footer}</div>}
      </div>
    </div>
  );
}
