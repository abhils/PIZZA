import { useCart } from '../context/CartContext.jsx';

export default function Toast({ raised }) {
  const { toast } = useCart();
  return (
    <div aria-live="polite" role="status" className={`pointer-events-none fixed left-1/2 z-[70] w-[min(92vw,26rem)] -translate-x-1/2 ${raised ? 'bottom-24' : 'bottom-6'}`}>
      {toast && (
        <p key={toast.id} className="anim-toast rounded-xl bg-navy px-4 py-3 text-center text-sm font-semibold text-white shadow-xl">
          {toast.message}
        </p>
      )}
    </div>
  );
}
