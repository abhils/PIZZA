import { Clock, Info } from 'lucide-react';
import { formatINR } from '../utils/priceUtils.js';
import { cleanText, normaliseMobile } from '../utils/validationUtils.js';
import { ORDER_RULES } from '../data/config.js';

const Row = ({ k, v }) => (
  <div className="flex gap-2 text-sm">
    <dt className="w-28 shrink-0 font-semibold text-ink/70">{k}</dt>
    <dd className="min-w-0 break-words font-semibold text-navy">{v}</dd>
  </div>
);

export default function OrderSummary({ orderType, details, lines, totals, opened, fallbackUrl, blocked }) {
  const isDelivery = orderType === 'delivery';

  return (
    <div className="space-y-5">
      <section aria-labelledby="sum-customer" className="rounded-2xl border border-gold/70 bg-white p-4">
        <h3 id="sum-customer" className="mb-2 font-display text-base font-extrabold text-navy">
          {isDelivery ? 'Home Delivery' : 'Dine-In'} details
        </h3>
        <dl className="space-y-1">
          <Row k="Name" v={cleanText(details.name, 80)} />
          {isDelivery ? (
            <>
              <Row k="Mobile" v={normaliseMobile(details.mobile)} />
              <Row k="Address" v={cleanText(details.address, 250)} />
              <Row k="Street/Landmark" v={cleanText(details.landmark, 120)} />
              <Row k="Area" v={cleanText(details.area, 100)} />
              <Row k="City/Village" v={cleanText(details.city, 100)} />
              {cleanText(details.instructions, 250) && <Row k="Instructions" v={cleanText(details.instructions, 250)} />}
            </>
          ) : (
            <>
              <Row k="Table" v={cleanText(details.table, 10)} />
              {normaliseMobile(details.mobile) && <Row k="Mobile" v={normaliseMobile(details.mobile)} />}
            </>
          )}
        </dl>
      </section>

      <section aria-labelledby="sum-items" className="rounded-2xl border border-gold/70 bg-white p-4">
        <h3 id="sum-items" className="mb-2 font-display text-base font-extrabold text-navy">
          Your items
        </h3>
        <ul className="divide-y divide-gold/40">
          {lines.map((l) => (
            <li key={l.key} className="flex items-start justify-between gap-3 py-2.5 text-sm">
              <div className="min-w-0">
                <p className="font-bold text-navy">
                  {l.name}
                  {l.sizeName ? ` — ${l.sizeName}` : ''}
                </p>
                {l.extras.length > 0 && <p className="text-xs text-ink/70">+ {l.extras.map((e) => e.name).join(', ')}</p>}
                <p className="text-xs text-ink/70">
                  {l.qty} × {l.priced ? formatINR(l.unitPrice) : 'MRP'}
                </p>
              </div>
              <p className="shrink-0 font-extrabold text-navy">{l.priced ? formatINR(l.lineTotal) : 'To be confirmed'}</p>
            </li>
          ))}
        </ul>
      </section>

      <section aria-labelledby="sum-bill" className="rounded-2xl border-2 border-navy bg-white p-4">
        <h3 id="sum-bill" className="mb-2 font-display text-base font-extrabold text-navy">
          Bill summary
        </h3>
        <dl className="space-y-1.5 text-sm">
          <div className="flex justify-between">
            <dt>{totals.hasUnpriced ? 'Known food subtotal' : 'Food subtotal'}</dt>
            <dd className="font-bold">{formatINR(totals.subtotal)}</dd>
          </div>
          <div className="flex justify-between">
            <dt>Home delivery charge</dt>
            <dd className="font-bold">{isDelivery ? formatINR(totals.deliveryCharge) : '₹0 (not applicable)'}</dd>
          </div>
          <div className="flex justify-between">
            <dt>Taxes</dt>
            <dd className="font-bold">Extra — to be confirmed</dd>
          </div>
          <div className="mt-2 flex justify-between border-t border-gold pt-2 text-base">
            <dt className="font-extrabold text-navy">{totals.hasUnpriced ? 'Known total (not final)' : 'Known total'}</dt>
            <dd className="text-xl font-extrabold text-brand-red">{formatINR(totals.knownTotal)}</dd>
          </div>
        </dl>
        {totals.hasUnpriced && (
          <p className="mt-3 flex items-start gap-2 rounded-lg bg-gold/25 p-2.5 text-xs font-semibold text-navy">
            <Info className="mt-0.5 h-4 w-4 shrink-0" aria-hidden="true" />
            {totals.unpricedCount} MRP item{totals.unpricedCount > 1 ? 's have' : ' has'} no confirmed price. The final amount (including taxes) will be confirmed by the restaurant on WhatsApp.
          </p>
        )}
        {isDelivery && (
          <p className="mt-2 flex items-start gap-2 text-xs text-ink/70">
            <Clock className="mt-0.5 h-4 w-4 shrink-0" aria-hidden="true" />
            Last Home Delivery Order: {ORDER_RULES.lastDeliveryOrderTime}
          </p>
        )}
      </section>

      {blocked && (
        <p role="alert" className="rounded-xl border border-brand-red/50 bg-brand-red/10 p-3 text-sm font-semibold text-navy">
          {blocked}
        </p>
      )}

      {opened && (
        <div role="status" className="rounded-xl border border-forest/50 bg-forest/10 p-3 text-sm text-navy">
          <p className="font-bold">WhatsApp should now be open with your order typed in.</p>
          <p className="mt-1">
            Your order is <strong>not placed yet</strong> — please press <strong>Send</strong> in WhatsApp. The restaurant will then confirm availability and the final bill. Your cart here is kept until you clear it.
          </p>
          <p className="mt-2">
            WhatsApp didn’t open?{' '}
            <a href={fallbackUrl} target="_blank" rel="noopener noreferrer" className="font-bold text-forest underline">
              Tap here to open it
            </a>
            .
          </p>
        </div>
      )}
    </div>
  );
}
