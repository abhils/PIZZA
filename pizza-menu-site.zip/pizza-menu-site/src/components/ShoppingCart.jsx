import { ShoppingBag } from 'lucide-react';
import Modal from './Modal.jsx';
import CartItem from './CartItem.jsx';
import { useCart } from '../context/CartContext.jsx';
import { formatINR } from '../utils/priceUtils.js';
import { ORDER_RULES } from '../data/config.js';

export default function ShoppingCart({ onClose, onCheckout }) {
  const { lines, isEmpty, totalsFor, clear } = useCart();
  const totals = totalsFor(null);

  const footer = isEmpty ? null : (
    <div>
      <div className="mb-3 space-y-1 text-sm">
        <div className="flex justify-between">
          <span className="font-semibold text-navy">{totals.hasUnpriced ? 'Known subtotal' : 'Food subtotal'}</span>
          <span className="text-lg font-extrabold text-navy">{formatINR(totals.subtotal)}</span>
        </div>
        {totals.hasUnpriced && (
          <p className="rounded-lg bg-gold/25 px-3 py-2 text-xs font-medium text-navy">
            {totals.unpricedCount} item{totals.unpricedCount > 1 ? 's are' : ' is'} MRP — the final amount will be confirmed by the restaurant on WhatsApp.
          </p>
        )}
        <p className="text-xs text-ink/70">
          Home delivery: ₹{ORDER_RULES.deliveryCharge} per order · minimum food order ₹{ORDER_RULES.deliveryMinimum}. {ORDER_RULES.taxNote}
        </p>
      </div>
      <div className="grid grid-cols-2 gap-2">
        <button type="button" onClick={onClose} className="h-12 rounded-xl border-2 border-navy bg-white text-sm font-bold text-navy transition hover:bg-cream">
          Continue Shopping
        </button>
        <button type="button" onClick={onCheckout} className="h-12 rounded-xl bg-brand-red text-sm font-bold text-white transition hover:bg-brand-red-dark">
          Checkout
        </button>
      </div>
    </div>
  );

  return (
    <Modal variant="drawer" title="Your Cart" titleId="cart-title" onClose={onClose} closeLabel="Close cart" footer={footer}>
      {isEmpty ? (
        <div className="grid h-full place-items-center py-10 text-center">
          <div>
            <span className="mx-auto grid h-20 w-20 place-items-center rounded-full border border-gold bg-white text-gold">
              <ShoppingBag className="h-9 w-9" />
            </span>
            <h3 className="mt-4 font-display text-xl font-extrabold text-navy">Your cart is empty</h3>
            <p className="mx-auto mt-1 max-w-xs text-sm text-ink/75">Browse the menu and add something delicious.</p>
            <a href="#menu" onClick={onClose} className="mt-5 inline-flex h-12 items-center rounded-full bg-brand-red px-7 text-sm font-bold text-white">
              Browse Menu
            </a>
          </div>
        </div>
      ) : (
        <>
          <ul className="space-y-3">
            {lines.map((l) => (
              <CartItem key={l.key} line={l} />
            ))}
          </ul>
          <button type="button" onClick={clear} className="mt-4 text-sm font-semibold text-brand-red underline underline-offset-2">
            Clear cart
          </button>
        </>
      )}
    </Modal>
  );
}
