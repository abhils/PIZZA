import { Minus, Plus, Trash2 } from 'lucide-react';
import { formatINR } from '../utils/priceUtils.js';
import { useCart } from '../context/CartContext.jsx';

export default function CartItem({ line }) {
  const { inc, dec, remove } = useCart();
  const label = line.sizeName ? `${line.name} (${line.sizeName})` : line.name;

  return (
    <li className="rounded-2xl border border-gold/70 bg-white p-3">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="font-display text-base font-extrabold leading-snug text-navy">{line.name}</p>
          {line.sizeName && <p className="text-sm font-semibold text-forest">Size: {line.sizeName}</p>}
          {line.extras.length > 0 && (
            <p className="text-sm text-ink/75">
              + {line.extras.map((e) => `${e.name} (${formatINR(e.price)})`).join(', ')}
            </p>
          )}
        </div>
        <button
          type="button"
          onClick={() => remove(line.key)}
          aria-label={`Remove ${label} from cart`}
          className="grid h-10 w-10 shrink-0 place-items-center rounded-full text-brand-red transition hover:bg-brand-red/10"
        >
          <Trash2 className="h-5 w-5" />
        </button>
      </div>

      <div className="mt-2 flex items-center justify-between gap-3">
        <div className="flex items-center rounded-full border border-gold bg-ivory" role="group" aria-label={`Quantity of ${label}`}>
          <button type="button" onClick={() => dec(line.key)} aria-label={`Decrease quantity of ${label}`} className="grid h-11 w-11 place-items-center rounded-full text-navy">
            <Minus className="h-4 w-4" />
          </button>
          <span className="w-7 text-center text-sm font-extrabold text-navy" aria-live="polite">
            {line.qty}
          </span>
          <button type="button" onClick={() => inc(line.key)} aria-label={`Increase quantity of ${label}`} className="grid h-11 w-11 place-items-center rounded-full text-navy">
            <Plus className="h-4 w-4" />
          </button>
        </div>

        <div className="text-right">
          {line.priced ? (
            <>
              <p className="text-xs text-ink/70">
                {formatINR(line.unitPrice)} each
              </p>
              <p className="text-lg font-extrabold text-navy">{formatINR(line.lineTotal)}</p>
            </>
          ) : (
            <>
              <p className="text-sm font-extrabold text-navy">MRP</p>
              <p className="max-w-[9rem] text-xs text-ink/70">Price to be confirmed by restaurant</p>
            </>
          )}
        </div>
      </div>
    </li>
  );
}
