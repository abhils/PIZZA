import { useEffect, useRef, useState } from 'react';
import { CATEGORIES } from '../data/menuData.js';

export default function CategoryNavigation() {
  const [active, setActive] = useState(CATEGORIES[0].id);
  const scroller = useRef(null);

  // Highlight the category whose section is currently under the sticky bars.
  // Active = the last section whose top has passed just under the two sticky bars.
  useEffect(() => {
    const sections = CATEGORIES.map((c) => document.getElementById(c.id)).filter(Boolean);
    if (!sections.length) return;
    let frame = 0;
    const update = () => {
      frame = 0;
      let current = sections[0].id;
      for (const s of sections) {
        if (s.getBoundingClientRect().top <= 150) current = s.id;
        else break;
      }
      setActive(current);
    };
    const onScroll = () => {
      if (!frame) frame = requestAnimationFrame(update);
    };
    update();
    window.addEventListener('scroll', onScroll, { passive: true });
    window.addEventListener('resize', onScroll);
    return () => {
      window.removeEventListener('scroll', onScroll);
      window.removeEventListener('resize', onScroll);
      if (frame) cancelAnimationFrame(frame);
    };
  }, []);

  // Keep the active chip visible inside the horizontal scroller (without scrolling the page).
  useEffect(() => {
    const box = scroller.current;
    const chip = box?.querySelector(`[data-cat="${active}"]`);
    if (!box || !chip) return;
    const target = chip.offsetLeft - box.clientWidth / 2 + chip.clientWidth / 2;
    box.scrollTo({ left: target, behavior: 'smooth' });
  }, [active]);

  return (
    <nav aria-label="Menu categories" className="sticky top-16 z-30 border-b border-gold/70 bg-cream/95 backdrop-blur">
      <div ref={scroller} className="no-scrollbar mx-auto flex max-w-7xl gap-2 overflow-x-auto px-4 py-2.5">
        {CATEGORIES.map((c) => {
          const on = c.id === active;
          return (
            <a
              key={c.id}
              href={`#${c.id}`}
              data-cat={c.id}
              aria-current={on ? 'true' : undefined}
              className={`flex h-10 shrink-0 items-center gap-1.5 whitespace-nowrap rounded-full border px-4 text-sm font-bold transition ${
                on ? 'border-brand-red bg-brand-red text-white shadow-sm' : 'border-gold bg-white text-navy hover:bg-ivory'
              }`}
            >
              <span aria-hidden="true">{c.emoji}</span>
              {c.name}
            </a>
          );
        })}
      </div>
    </nav>
  );
}
