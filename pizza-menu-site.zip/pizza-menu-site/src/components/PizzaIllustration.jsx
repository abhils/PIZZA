import { useId } from 'react';

// Original vector pizza used in the hero. Swap for a real photo by replacing this component's usage in HeroSection.

const polar = (r, deg) => [200 + r * Math.cos((deg * Math.PI) / 180), 200 + r * Math.sin((deg * Math.PI) / 180)];

const GREEN = [
  [78, 20], [112, 62], [96, 150], [60, 200], [118, 255], [84, 300], [124, 335], [52, 100],
].map(([r, d]) => polar(r, d));
const OLIVES = [
  [95, 40], [70, 120], [120, 180], [100, 230], [64, 280], [122, 15], [48, 330],
].map(([r, d]) => polar(r, d));
const CORN = Array.from({ length: 22 }, (_, i) => polar(40 + ((i * 37) % 95), i * 47));
const RED = [
  [100, 80], [60, 165], [110, 205], [75, 245], [104, 310], [40, 55],
].map(([r, d]) => polar(r, d));

export default function PizzaIllustration({ className = '', decorative = false }) {
  const uid = useId().replace(/:/g, '');
  const cheeseId = `pz-cheese-${uid}`;
  const shadowId = `pz-shadow-${uid}`;
  return (
    <svg
      viewBox="0 0 400 400"
      className={className}
      {...(decorative ? { 'aria-hidden': 'true' } : { role: 'img', 'aria-label': 'Illustration of a freshly baked vegetarian pizza' })}
    >
      <defs>
        <radialGradient id={cheeseId} cx="45%" cy="40%" r="70%">
          <stop offset="0" stopColor="#FBD96B" />
          <stop offset="1" stopColor="#F1B83A" />
        </radialGradient>
        <filter id={shadowId} x="-20%" y="-20%" width="140%" height="140%">
          <feDropShadow dx="0" dy="14" stdDeviation="14" floodColor="#071B33" floodOpacity="0.28" />
        </filter>
      </defs>
      <circle cx="200" cy="200" r="190" fill="#F8F0DF" stroke="#DDBB79" strokeWidth="3" />
      <g filter={`url(#${shadowId})`}>
        <circle cx="200" cy="200" r="158" fill="#D9963F" />
        <circle cx="200" cy="200" r="146" fill="#EDB25A" />
        <circle cx="200" cy="200" r="132" fill="#C8281F" />
        <circle cx="200" cy="200" r="126" fill={`url(#${cheeseId})`} />
      </g>
      {RED.map(([x, y], i) => (
        <rect key={'r' + i} x={x - 9} y={y - 5} width="18" height="10" rx="5" fill="#E7192D" transform={`rotate(${i * 40} ${x} ${y})`} />
      ))}
      {GREEN.map(([x, y], i) => (
        <path key={'g' + i} d={`M${x - 15} ${y} a15 11 0 0 1 30 0`} fill="none" stroke="#176B3A" strokeWidth="6" strokeLinecap="round" transform={`rotate(${i * 47} ${x} ${y})`} />
      ))}
      {OLIVES.map(([x, y], i) => (
        <g key={'o' + i}>
          <circle cx={x} cy={y} r="9" fill="#1c1c24" />
          <circle cx={x} cy={y} r="3.4" fill="#F1B83A" />
        </g>
      ))}
      {CORN.map(([x, y], i) => (
        <circle key={'c' + i} cx={x} cy={y} r="4.2" fill="#FFE27A" stroke="#E0A920" strokeWidth="1" />
      ))}
      {[0, 45, 90, 135].map((a) => (
        <line key={a} x1={polar(126, a)[0]} y1={polar(126, a)[1]} x2={polar(126, a + 180)[0]} y2={polar(126, a + 180)[1]} stroke="#B97A2B" strokeOpacity="0.45" strokeWidth="2" />
      ))}
    </svg>
  );
}
