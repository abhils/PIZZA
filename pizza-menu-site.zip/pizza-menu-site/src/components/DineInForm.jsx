import Field from './Field.jsx';

export default function DineInForm({ id, details, errors, onChange, onSubmit }) {
  const set = (k) => (e) => onChange({ [k]: e.target.value });

  return (
    <form id={id} onSubmit={onSubmit} noValidate className="space-y-4">
      <div>
        <h3 className="font-display text-lg font-extrabold text-navy">Dine-In Order</h3>
        <p className="mt-1 text-sm text-ink/75">Enter your table number so the restaurant team can identify your order.</p>
      </div>
      <Field label="Customer Name" required value={details.name} onChange={set('name')} error={errors.name} placeholder="Enter your name" autoComplete="name" maxLength={80} />
      <Field
        label="Table Number"
        required
        inputMode="numeric"
        value={details.table}
        onChange={set('table')}
        error={errors.table}
        placeholder="Enter your table number"
        maxLength={10}
        autoComplete="off"
      />
      <Field
        label="Mobile Number"
        type="tel"
        inputMode="numeric"
        autoComplete="tel-national"
        value={details.mobile}
        onChange={set('mobile')}
        error={errors.mobile}
        placeholder="Optional contact number"
        maxLength={16}
      />
    </form>
  );
}
