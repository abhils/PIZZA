import { useState } from 'react';
import { CATEGORIES } from '../data/menuData.js';
import PizzaIllustration from './PizzaIllustration.jsx';

const TINTS = ['#FDE9C9', '#FBE0D8', '#E4F1E2', '#FFF1C9', '#E7ECF7', '#F6E3EE'];
const EMOJI = Object.fromEntries(CATEGORIES.map((c) => [c.id, c.emoji]));

/**
 * Shows the product photo when `product.image` is set (and loads); otherwise a clean
 * illustrated tile. To use real photos: put files in /public/images and set `image`
 * on the product in src/data/menuData.js (e.g. image: '/images/laden-pizza.webp').
 */
export default function FoodImage({ product, eager = false }) {
  const [failed, setFailed] = useState(false);
  const tint = TINTS[[...product.id].reduce((a, c) => a + c.charCodeAt(0), 0) % TINTS.length];

  return (
    <div className="food-zoom relative aspect-[4/3] w-full overflow-hidden rounded-xl" style={{ background: tint }}>
      {product.image && !failed ? (
        <img
          src={product.image}
          alt={`${product.name}${product.description ? ' — ' + product.description : ''}`}
          loading={eager ? 'eager' : 'lazy'}
          decoding="async"
          width="400"
          height="300"
          onError={() => setFailed(true)}
          className="h-full w-full object-cover"
        />
      ) : (
        <div className="grid h-full w-full place-items-center" role="img" aria-label={`${product.name} illustration`}>
          {product.category === 'pizzas' || product.category === 'mini-pizzas' ? (
            // Vector veg pizza so vegetarian items never show a meat-topped emoji.
            <PizzaIllustration decorative className="food-emoji h-[88%] w-auto" />
          ) : (
            <span className="food-emoji select-none text-6xl drop-shadow-sm sm:text-7xl">{product.emoji || EMOJI[product.category] || '🍽️'}</span>
          )}
        </div>
      )}
    </div>
  );
}
