import { useEffect, useRef, useState } from 'react';
import { Check, Flame, Minus, Plus } from 'lucide-react';
import { useCart } from '../context/CartContext.jsx';
import { formatINR, priceLabel } from '../utils/priceUtils.js';
import FoodImage from './FoodImage.jsx';
import PizzaSizeSelector from './PizzaSizeSelector.jsx';
import { VegBadge } from './icons.jsx';

export default function MenuItemCard({ product, eager = false }) {
  const { add } = useCart();
  const [size, setSize] = useState(null);
  const [qty, setQty] = useState(1);
  const [extraIds, setExtraIds] = useState([]);
  const [justAdded, setJustAdded] = useState(false);
  const timer = useRef(null);
  useEffect(() => () => clearTimeout(timer.current), []);

  const needsSize = Boolean(product.sizes);
  const isMrp = !needsSize && typeof product.price !== 'number';
  const base = needsSize ? product.sizes.find((s) => s.name === size)?.price ?? null : product.price;
  const extrasTotal = (product.extras || []).filter((e) => extraIds.includes(e.id)).reduce((s, e) => s + e.price, 0);
  const canAdd = !needsSize || size !== null;

  const toggleExtra = (id) => setExtraIds((cur) => (cur.includes(id) ? cur.filter((x) => x !== id) : [...cur, id]));

  const handleAdd = () => {
    if (!canAdd) return;
    add({ productId: product.id, size, extraIds, qty });
    setQty(1);
    setExtraIds([]);
    setJustAdded(true);
    clearTimeout(timer.current);
    timer.current = setTimeout(() => setJustAdded(false), 1400);
  };

  return (
    <article className="card-hover flex flex-col rounded-2xl border border-gold/80 bg-white p-3 shadow-sm">
      <FoodImage product={product} eager={eager} />

      <div className="mt-3 flex flex-1 flex-col">
        <div className="flex flex-wrap items-center gap-x-3 gap-y-1">
          {product.veg && <VegBadge />}
          {product.spicy && (
            <span className="inline-flex items-center gap-1 text-[11px] font-bold text-brand-red">
              <Flame className="h-3.5 w-3.5" aria-hidden="true" /> Spicy
            </span>
          )}
        </div>

        <h3 className="mt-1 font-display text-lg font-extrabold leading-snug text-navy">{product.name}</h3>
        {product.description && <p className="mt-1 text-sm leading-snug text-ink/75">{product.description}</p>}

        {needsSize ? (
          <PizzaSizeSelector productId={product.id} sizes={product.sizes} value={size} onChange={setSize} />
        ) : null}

        {(product.extras || []).length > 0 && (
          <div className="mt-3 space-y-1.5">
            {product.extras.map((e) => (
              <label key={e.id} className="flex min-h-10 cursor-pointer items-center gap-2.5 rounded-lg border border-gold/60 bg-cream/60 px-3 text-sm font-semibold text-navy">
                <input
                  type="checkbox"
                  checked={extraIds.includes(e.id)}
                  onChange={() => toggleExtra(e.id)}
                  className="h-4 w-4 accent-[#176b3a]"
                />
                <span className="flex-1">{e.name}</span>
                <span className="font-bold">+{formatINR(e.price)}</span>
              </label>
            ))}
          </div>
        )}

        <div className="mt-auto pt-3">
          <div className="mb-2 flex items-end justify-between gap-2">
            <div>
              {needsSize && base === null && (
                <p className="text-sm font-bold text-navy">{priceLabel(product)}</p>
              )}
              {needsSize && base !== null && <p className="text-xl font-extrabold text-brand-red">{formatINR(base + extrasTotal)}</p>}
              {!needsSize && !isMrp && <p className="text-xl font-extrabold text-brand-red">{formatINR(product.price + extrasTotal)}</p>}
              {isMrp && (
                <p>
                  <span className="rounded-md bg-navy px-2 py-0.5 text-sm font-extrabold text-white">MRP</span>
                  <span className="mt-1 block text-xs text-ink/70">Price to be confirmed by restaurant</span>
                </p>
              )}
            </div>

            <div className="flex items-center rounded-full border border-gold bg-ivory" role="group" aria-label={`Quantity for ${product.name}`}>
              <button
                type="button"
                onClick={() => setQty((q) => Math.max(1, q - 1))}
                disabled={qty <= 1}
                aria-label="Decrease quantity"
                className="grid h-11 w-11 place-items-center rounded-full text-navy disabled:opacity-40"
              >
                <Minus className="h-4 w-4" />
              </button>
              <span className="w-6 text-center text-sm font-extrabold text-navy" aria-live="polite">
                {qty}
              </span>
              <button
                type="button"
                onClick={() => setQty((q) => Math.min(20, q + 1))}
                aria-label="Increase quantity"
                className="grid h-11 w-11 place-items-center rounded-full text-navy"
              >
                <Plus className="h-4 w-4" />
              </button>
            </div>
          </div>

          <button
            type="button"
            onClick={handleAdd}
            disabled={!canAdd}
            className={`flex h-12 w-full items-center justify-center gap-2 rounded-xl text-sm font-bold transition ${
              justAdded
                ? 'bg-forest text-white'
                : canAdd
                  ? 'bg-brand-red text-white hover:bg-brand-red-dark'
                  : 'cursor-not-allowed border border-dashed border-gold bg-cream text-ink/60'
            }`}
          >
            {justAdded ? (
              <>
                <Check className="h-4 w-4" /> Added
              </>
            ) : canAdd ? (
              'Add to Cart'
            ) : (
              'Select a size to add'
            )}
          </button>
        </div>
      </div>
    </article>
  );
}
