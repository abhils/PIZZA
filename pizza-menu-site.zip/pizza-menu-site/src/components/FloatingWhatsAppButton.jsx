import { buildEnquiryUrl } from '../utils/whatsappUtils.js';
import { WhatsAppIcon } from './icons.jsx';

/**
 * General enquiry button (not an order button). Orders always go through the
 * checkout popup so delivery/dine-in details are collected first.
 * `raised` lifts it above the mobile cart bar.
 */
export default function FloatingWhatsAppButton({ raised }) {
  return (
    <a
      href={buildEnquiryUrl()}
      target="_blank"
      rel="noopener noreferrer"
      aria-label="Chat with the restaurant on WhatsApp (opens in a new tab)"
      className={`fixed right-4 z-30 grid h-14 w-14 place-items-center rounded-full bg-[#25D366] text-white shadow-lg ring-4 ring-white/80 transition hover:scale-110 sm:bottom-6 sm:h-16 sm:w-16 ${
        raised ? 'bottom-24' : 'bottom-5'
      }`}
    >
      <WhatsAppIcon className="h-8 w-8 sm:h-9 sm:w-9" />
    </a>
  );
}
