import { formatINR } from '../utils/priceUtils.js';

/** Radio-group style size picker. `value` is a size name or null (nothing chosen yet). */
export default function PizzaSizeSelector({ productId, sizes, value, onChange }) {
  return (
    <fieldset className="mt-3">
      <legend className="mb-1.5 text-xs font-bold uppercase tracking-wide text-ink/70">Choose size</legend>
      <div className="grid grid-cols-2 gap-2">
        {sizes.map((s) => {
          const selected = value === s.name;
          return (
            <label
              key={s.name}
              className={`flex min-h-12 cursor-pointer flex-col items-center justify-center rounded-xl border-2 px-2 py-1.5 text-center transition has-[:focus-visible]:outline-3 has-[:focus-visible]:outline-offset-2 has-[:focus-visible]:outline-navy ${
                selected ? 'border-brand-red bg-brand-red/10 text-navy' : 'border-gold/70 bg-white text-navy hover:border-gold'
              }`}
            >
              <input
                type="radio"
                name={`size-${productId}`}
                value={s.name}
                checked={selected}
                onChange={() => onChange(s.name)}
                className="sr-only"
              />
              <span className="text-xs font-semibold">{s.name}</span>
              <span className="text-sm font-extrabold">{formatINR(s.price)}</span>
            </label>
          );
        })}
      </div>
    </fieldset>
  );
}
