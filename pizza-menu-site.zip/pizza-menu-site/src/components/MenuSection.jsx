import { Info } from 'lucide-react';
import MenuItemCard from './MenuItemCard.jsx';

/** Groups products by optional `subgroup` (e.g. Mini Single Topping) while preserving order. */
function groupProducts(products) {
  const groups = [];
  products.forEach((p) => {
    const name = p.subgroup || '';
    let g = groups.find((x) => x.name === name);
    if (!g) groups.push((g = { name, items: [] }));
    g.items.push(p);
  });
  return groups;
}

export default function MenuSection({ category, products, index }) {
  const groups = groupProducts(products);
  return (
    <section id={category.id} aria-labelledby={`${category.id}-title`} className="scroll-mt-32 py-8">
      <div className="mb-5">
        <h2 id={`${category.id}-title`} className="brush text-2xl sm:text-3xl">
          {category.name}
        </h2>
        {category.notes.map((n) => (
          <p key={n} className="mt-3 flex items-start gap-2 text-sm font-medium text-navy/85">
            <Info className="mt-0.5 h-4 w-4 shrink-0 text-forest" aria-hidden="true" />
            <span>{n}</span>
          </p>
        ))}
        <div className="mt-4 h-px bg-gradient-to-r from-gold via-gold/40 to-transparent" aria-hidden="true" />
      </div>

      {groups.map((g) => (
        <div key={g.name || 'all'} className="mb-6">
          {g.name && <h3 className="mb-3 font-display text-lg font-extrabold text-forest">{g.name}</h3>}
          <div className="grid grid-cols-1 gap-4 min-[520px]:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {g.items.map((p) => (
              <MenuItemCard key={`${category.id}-${p.id}`} product={p} eager={index === 0 && g.items.indexOf(p) < 2} />
            ))}
          </div>
        </div>
      ))}
    </section>
  );
}
