import { BUSINESS } from '../data/config.js';
import { InstagramIcon } from './icons.jsx';

export default function InstagramSection() {
  return (
    <section aria-labelledby="insta-title" className="mx-auto max-w-7xl px-4 py-10">
      <div className="relative overflow-hidden rounded-3xl border-2 border-gold bg-white p-6 text-center shadow-sm sm:p-10">
        <div className="pointer-events-none absolute -left-10 -top-10 h-40 w-40 rounded-full bg-brand-red/10" aria-hidden="true" />
        <div className="pointer-events-none absolute -bottom-12 -right-12 h-48 w-48 rounded-full bg-forest/10" aria-hidden="true" />
        <div className="relative">
          <span className="mx-auto grid h-16 w-16 place-items-center rounded-full bg-navy text-white">
            <InstagramIcon className="h-8 w-8" />
          </span>
          <h2 id="insta-title" className="mt-4 font-display text-3xl font-extrabold text-navy">
            Follow Us on Instagram
          </h2>
          <p className="mx-auto mt-2 max-w-md text-ink/80">Discover our latest updates, food specials, and offers.</p>
          <p className="mt-3 font-display text-xl font-extrabold text-brand-red">{BUSINESS.instagramHandle}</p>
          <a
            href={BUSINESS.instagramUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="mt-5 inline-flex h-12 items-center gap-2 rounded-full bg-navy px-7 text-base font-bold text-white transition hover:bg-brand-red"
          >
            <InstagramIcon className="h-5 w-5" /> Follow on Instagram
          </a>
        </div>
      </div>
    </section>
  );
}
