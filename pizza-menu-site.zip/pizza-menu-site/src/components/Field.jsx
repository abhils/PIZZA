import { useId } from 'react';

/** Labelled input/textarea with an associated, announced error message. */
export default function Field({ label, error, hint, required, multiline = false, className = '', ...inputProps }) {
  const id = useId();
  const errId = `${id}-err`;
  const hintId = `${id}-hint`;
  const Tag = multiline ? 'textarea' : 'input';
  return (
    <div className={className}>
      <label htmlFor={id} className="mb-1 block text-sm font-bold text-navy">
        {label} {required ? <span className="text-brand-red" aria-hidden="true">*</span> : <span className="font-medium text-ink/60">(optional)</span>}
      </label>
      <Tag
        id={id}
        aria-required={required || undefined}
        aria-invalid={error ? 'true' : undefined}
        aria-describedby={[error ? errId : null, hint ? hintId : null].filter(Boolean).join(' ') || undefined}
        className={`w-full rounded-xl border-2 bg-white px-3.5 py-3 text-base text-ink placeholder:text-ink/40 focus:border-navy focus:outline-none ${
          error ? 'border-brand-red' : 'border-gold/80'
        } ${multiline ? 'min-h-24 resize-y' : 'h-12'}`}
        {...inputProps}
      />
      {hint && !error && (
        <p id={hintId} className="mt-1 text-xs text-ink/65">
          {hint}
        </p>
      )}
      {error && (
        <p id={errId} role="alert" className="mt-1 text-sm font-semibold text-brand-red">
          {error}
        </p>
      )}
    </div>
  );
}
