import { useMemo, useState } from 'react';
import { ArrowLeft, Pencil } from 'lucide-react';
import Modal from './Modal.jsx';
import OrderTypeSelector from './OrderTypeSelector.jsx';
import DeliveryForm from './DeliveryForm.jsx';
import DineInForm from './DineInForm.jsx';
import OrderSummary from './OrderSummary.jsx';
import { WhatsAppIcon } from './icons.jsx';
import { useCart } from '../context/CartContext.jsx';
import { validateDelivery, validateDineIn } from '../utils/validationUtils.js';
import { buildOrderUrl, openWhatsApp } from '../utils/whatsappUtils.js';
import { ORDER_RULES } from '../data/config.js';

const FORM_ID = 'checkout-details-form';
const TITLES = {
  type: 'How Would You Like to Receive Your Order?',
  details: 'Your Details',
  summary: 'Review Your Order',
};

/**
 * Checkout state machine:  type → details → summary → (WhatsApp)
 * Back never loses the cart or typed details (details live in App state).
 * The popup always starts at "type" because this component mounts fresh for each checkout.
 */
export default function CheckoutModal({ details, setDetails, onClose, onEditOrder }) {
  const { lines, totalsFor } = useCart();
  const [step, setStep] = useState('type');
  const [orderType, setOrderType] = useState(null);
  const [errors, setErrors] = useState({});
  const [opened, setOpened] = useState(false);

  // Totals always recalculate from the current order type (delivery fee / minimum).
  const totals = totalsFor(orderType);
  const params = useMemo(() => ({ orderType, details, lines, totals }), [orderType, details, lines, totals]);

  const isDelivery = orderType === 'delivery';
  const blocked =
    lines.length === 0
      ? 'Your cart is empty. Add items from the menu first.'
      : isDelivery && !totals.meetsMinimum
        ? `Home delivery needs a food subtotal of at least ₹${ORDER_RULES.deliveryMinimum}. Add ₹${totals.shortBy} more or choose Dine-In.`
        : null;

  const patchDetails = (patch) => {
    setDetails((d) => ({ ...d, ...patch }));
    setErrors((e) => {
      const next = { ...e };
      Object.keys(patch).forEach((k) => delete next[k]);
      return next;
    });
  };

  const chooseType = (type) => {
    setOrderType(type);
    setErrors({});
    setOpened(false);
    setStep('details');
  };

  const submitDetails = (e) => {
    e.preventDefault();
    const found = isDelivery ? validateDelivery(details) : validateDineIn(details);
    setErrors(found);
    if (Object.keys(found).length > 0 || blocked) return;
    setOpened(false);
    setStep('summary');
  };

  const confirm = () => {
    if (blocked) return;
    // Final re-validation guards against stale state.
    const found = isDelivery ? validateDelivery(details) : validateDineIn(details);
    if (Object.keys(found).length > 0) {
      setErrors(found);
      setStep('details');
      return;
    }
    openWhatsApp(buildOrderUrl(params)); // user-initiated click; customer must press Send in WhatsApp
    setOpened(true);
  };

  const back = () => {
    if (step === 'summary') setStep('details');
    else if (step === 'details') setStep('type');
  };

  let footer = null;
  if (step === 'details') {
    footer = (
      <div className="grid grid-cols-[auto_1fr] gap-2">
        <button type="button" onClick={back} className="flex h-12 items-center gap-1.5 rounded-xl border-2 border-navy bg-white px-4 text-sm font-bold text-navy">
          <ArrowLeft className="h-4 w-4" /> Back
        </button>
        <button type="submit" form={FORM_ID} className="h-12 rounded-xl bg-brand-red text-sm font-bold text-white transition hover:bg-brand-red-dark">
          Review Order
        </button>
      </div>
    );
  } else if (step === 'summary') {
    footer = (
      <div className="space-y-2">
        <button
          type="button"
          onClick={confirm}
          disabled={Boolean(blocked)}
          className="flex h-12 w-full items-center justify-center gap-2 rounded-xl bg-forest text-sm font-bold text-white transition hover:bg-[#10542c] disabled:cursor-not-allowed disabled:opacity-50"
        >
          <WhatsAppIcon className="h-5 w-5" /> {opened ? 'Open WhatsApp Again' : 'Confirm & Order on WhatsApp'}
        </button>
        <div className="grid grid-cols-2 gap-2">
          <button type="button" onClick={back} className="flex h-11 items-center justify-center gap-1.5 rounded-xl border-2 border-navy bg-white text-sm font-bold text-navy">
            <ArrowLeft className="h-4 w-4" /> Back
          </button>
          <button type="button" onClick={onEditOrder} className="flex h-11 items-center justify-center gap-1.5 rounded-xl border-2 border-gold bg-white text-sm font-bold text-navy">
            <Pencil className="h-4 w-4" /> Edit Order
          </button>
        </div>
      </div>
    );
  }

  return (
    <Modal title={TITLES[step]} titleId="checkout-title" onClose={onClose} closeLabel="Close checkout" footer={footer}>
      {step === 'type' && <OrderTypeSelector selected={orderType} onSelect={chooseType} />}

      {step === 'details' && (
        <>
          <p className="mb-4 inline-flex items-center gap-2 rounded-full border border-gold bg-white py-1 pl-3 pr-1 text-xs font-bold text-navy">
            {isDelivery ? 'Home Delivery' : 'Dine-In'}
            <button type="button" onClick={() => setStep('type')} className="rounded-full bg-cream px-3 py-1.5 text-xs font-bold text-brand-red underline">
              Change
            </button>
          </p>
          {isDelivery ? (
            <DeliveryForm id={FORM_ID} details={details} errors={errors} totals={totals} onChange={patchDetails} onSubmit={submitDetails} />
          ) : (
            <DineInForm id={FORM_ID} details={details} errors={errors} onChange={patchDetails} onSubmit={submitDetails} />
          )}
          <p className="mt-5 text-xs text-ink/65">{ORDER_RULES.taxNote}</p>
        </>
      )}

      {step === 'summary' && (
        <OrderSummary
          orderType={orderType}
          details={details}
          lines={lines}
          totals={totals}
          opened={opened}
          blocked={blocked}
          fallbackUrl={buildOrderUrl(params)}
        />
      )}
    </Modal>
  );
}
