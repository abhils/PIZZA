import { Armchair, Bike } from 'lucide-react';
import { ORDER_RULES } from '../data/config.js';

const OPTIONS = [
  {
    type: 'delivery',
    icon: Bike,
    title: 'Home Delivery',
    description: 'Get your order delivered to your address.',
    button: 'Choose Home Delivery',
    tone: 'border-brand-red/70 hover:bg-brand-red/5',
    iconTone: 'bg-brand-red text-white',
    note: `Min. order ₹${ORDER_RULES.deliveryMinimum} · ₹${ORDER_RULES.deliveryCharge} delivery · last order ${ORDER_RULES.lastDeliveryOrderTime}`,
  },
  {
    type: 'dinein',
    icon: Armchair,
    title: 'Dine-In',
    description: 'Enjoy your order at the restaurant.',
    button: 'Choose Dine-In',
    tone: 'border-forest/70 hover:bg-forest/5',
    iconTone: 'bg-forest text-white',
    note: 'No delivery charge · table number needed',
  },
];

export default function OrderTypeSelector({ selected, onSelect }) {
  return (
    <div>
      <p className="mb-4 text-sm text-ink/75">Choose one to continue. You can come back and change it before you order.</p>
      <div className="grid gap-4 sm:grid-cols-2">
        {OPTIONS.map(({ type, icon: Icon, title, description, button, tone, iconTone, note }) => (
          <div
            key={type}
            className={`relative flex flex-col rounded-2xl border-2 bg-white p-5 text-center transition ${tone} ${
              selected === type ? 'ring-4 ring-gold' : ''
            }`}
          >
            <span className={`mx-auto grid h-16 w-16 place-items-center rounded-full ${iconTone}`}>
              <Icon className="h-8 w-8" aria-hidden="true" />
            </span>
            <h3 className="mt-3 font-display text-xl font-extrabold text-navy">{title}</h3>
            <p className="mt-1 text-sm text-ink/80">{description}</p>
            <p className="mt-2 text-xs font-medium text-ink/60">{note}</p>
            <button
              type="button"
              data-autofocus={type === 'delivery' ? '' : undefined}
              onClick={() => onSelect(type)}
              className={`mt-4 h-12 rounded-xl text-sm font-bold text-white after:absolute after:inset-0 after:rounded-2xl after:content-[''] ${
                type === 'delivery' ? 'bg-brand-red hover:bg-brand-red-dark' : 'bg-forest hover:bg-[#10542c]'
              }`}
            >
              {button}
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
