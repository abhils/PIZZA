import { ChefHat, Ruler, MessageCircle } from 'lucide-react';
import PizzaIllustration from './PizzaIllustration.jsx';
import { WhatsAppIcon } from './icons.jsx';

const POINTS = [
  { icon: ChefHat, label: 'Freshly Prepared' },
  { icon: Ruler, label: 'Multiple Pizza Sizes' },
  { icon: MessageCircle, label: 'Easy WhatsApp Ordering' },
];

export default function HeroSection({ onOrderNow }) {
  return (
    <section id="home" className="paper scroll-mt-20 border-b border-gold/60">
      <div className="mx-auto grid max-w-7xl items-center gap-8 px-4 py-10 md:grid-cols-2 md:py-14 lg:gap-14">
        <div>
          <p className="mb-3 inline-block rounded-full border border-gold bg-white px-3 py-1 text-xs font-bold uppercase tracking-wider text-forest">
            Pizza · Burgers · Pasta · Shakes
          </p>
          <h1 className="font-display text-4xl font-extrabold leading-[1.05] text-navy sm:text-5xl lg:text-6xl">
            Fresh, Hot &amp; <span className="text-brand-red">Delicious</span> Pizza
          </h1>
          <p className="mt-4 max-w-lg text-lg text-ink/80">Your favourites, freshly prepared and ready to order.</p>

          <div className="mt-6 flex flex-col gap-3 sm:flex-row">
            <a
              href="#menu"
              className="inline-flex h-12 items-center justify-center rounded-full bg-brand-red px-7 text-base font-bold text-white shadow-md transition hover:bg-brand-red-dark"
            >
              Explore Menu
            </a>
            <button
              type="button"
              onClick={onOrderNow}
              className="inline-flex h-12 items-center justify-center gap-2 rounded-full border-2 border-forest bg-white px-7 text-base font-bold text-forest transition hover:bg-forest hover:text-white"
            >
              <WhatsAppIcon className="h-5 w-5" /> Order on WhatsApp
            </button>
          </div>

          <ul className="mt-7 flex flex-wrap gap-x-6 gap-y-3 text-sm font-semibold text-navy">
            {POINTS.map(({ icon: Icon, label }) => (
              <li key={label} className="flex items-center gap-2">
                <span className="grid h-8 w-8 place-items-center rounded-full border border-gold bg-white text-forest">
                  <Icon className="h-4 w-4" aria-hidden="true" />
                </span>
                {label}
              </li>
            ))}
          </ul>
        </div>

        <div className="mx-auto w-full max-w-md md:max-w-none">
          <PizzaIllustration className="float-slow mx-auto h-auto w-full max-w-[26rem] drop-shadow-xl" />
        </div>
      </div>
    </section>
  );
}
