import { createContext, useCallback, useContext, useEffect, useMemo, useReducer, useRef, useState } from 'react';
import { cartReducer, loadCart, saveCart } from '../utils/cartUtils.js';
import { resolveLine, calcTotals } from '../utils/priceUtils.js';
import { PRODUCT_MAP } from '../data/menuData.js';

const CartContext = createContext(null);

export function CartProvider({ children }) {
  const [cart, dispatch] = useReducer(cartReducer, undefined, loadCart);
  const [bump, setBump] = useState(0); // increments on add → badge animation
  const [toast, setToast] = useState(null);
  const toastTimer = useRef(null);

  useEffect(() => saveCart(cart), [cart]);

  const showToast = useCallback((message) => {
    setToast({ message, id: Date.now() });
    clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToast(null), 2600);
  }, []);
  useEffect(() => () => clearTimeout(toastTimer.current), []);

  const lines = useMemo(() => cart.map(resolveLine).filter(Boolean), [cart]);

  const value = useMemo(
    () => ({
      lines,
      count: lines.reduce((s, l) => s + l.qty, 0),
      isEmpty: lines.length === 0,
      totalsFor: (orderType) => calcTotals(lines, orderType),
      bump,
      toast,
      showToast,
      add: ({ productId, size = null, extraIds = [], qty = 1 }) => {
        dispatch({ type: 'ADD', productId, size, extraIds, qty });
        setBump((b) => b + 1);
        showToast(`Added ${qty > 1 ? qty + ' × ' : ''}${PRODUCT_MAP[productId]?.name}${size ? ' (' + size + ')' : ''} to cart`);
      },
      inc: (key) => dispatch({ type: 'INC', key }),
      dec: (key) => dispatch({ type: 'DEC', key }),
      remove: (key) => dispatch({ type: 'REMOVE', key }),
      clear: () => dispatch({ type: 'CLEAR' }),
    }),
    [lines, bump, toast, showToast]
  );

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}

export function useCart() {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error('useCart must be used inside <CartProvider>');
  return ctx;
}
