// =====================================================================
//  CENTRAL MENU DATA — edit prices, names and items here only.
//
//  Product shapes
//   • Sized product   : sizes: [{ name, price }, ...]
//   • Fixed price     : price: 110
//   • MRP / unpriced  : price: null   (shown as "MRP — price to be confirmed")
//                       Set a number later once the restaurant provides it.
//
//  A product belongs to one `category` and may also be listed in other
//  categories via `alsoIn: [...]`. It always keeps ONE id and ONE price.
// =====================================================================

export const PIZZA_SIZES = ['Regular', 'Medium', 'Large', 'Giant'];

export const EXTRAS = {
  cheeseSlice: { id: 'cheese-slice', name: 'Extra Cheese Slice', price: 11 },
  extraScoop: { id: 'extra-scoop', name: 'Extra Ice Cream Scoop', price: 30 },
};

export const CATEGORIES = [
  { id: 'pizzas', name: 'Pizzas', icon: 'Pizza', emoji: '🍕', notes: ['Select a size to see the price. Sizes: Regular / Medium / Large / Giant.'] },
  { id: 'mini-pizzas', name: "Mini Range Pizza's", icon: 'Pizza', emoji: '🍕', notes: [] },
  { id: 'burgers', name: 'Burgers', icon: 'Hamburger', emoji: '🍔', notes: ['Additional cheese slice ₹11.'] },
  { id: 'sandwiches', name: 'Sandwiches', icon: 'Sandwich', emoji: '🥪', notes: ['Additional cheese slice ₹11.'] },
  { id: 'salad', name: 'Salad', icon: 'Salad', emoji: '🥗', notes: ['Additional veg patty ₹29 (not added automatically — mention it in your order on WhatsApp).'] },
  { id: 'newly-launched', name: 'Newly Launched', icon: 'Sparkles', emoji: '✨', notes: [] },
  { id: 'breads', name: "Bread's", icon: 'Croissant', emoji: '🥖', notes: ['Extra cheese dip ₹11 · Extra garlic bread ₹29 (mention in your WhatsApp order).'] },
  { id: 'dips', name: "Dip's", icon: 'Droplet', emoji: '🥣', notes: [] },
  { id: 'pastas', name: "Pasta's", icon: 'UtensilsCrossed', emoji: '🍝', notes: [] },
  { id: 'wraps', name: "Wrap's", icon: 'Utensils', emoji: '🌯', notes: [] },
  { id: 'fries-snacks', name: "Fries, Snack's & More", icon: 'Cookie', emoji: '🍟', notes: [] },
  { id: 'desserts', name: "Dessert's", icon: 'IceCreamCone', emoji: '🍰', notes: ['Taxes Extra.'] },
  { id: 'shakes', name: "Shake's", icon: 'GlassWater', emoji: '🥤', notes: ['Extra ice cream scoop ₹30 — tick “Extra Ice Cream Scoop” on a shake to add it.'] },
  { id: 'mojito', name: 'Mojito', icon: 'Martini', emoji: '🍹', notes: [] },
  { id: 'drinks', name: "Drink's", icon: 'CupSoda', emoji: '☕', notes: ['Items marked MRP are priced by the restaurant — the final amount is confirmed on WhatsApp.'] },
];

// ---------- helpers (data-building only) ----------
const slug = (s) =>
  s.toLowerCase().replace(/&/g, 'and').replace(/['’]/g, '').replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');

const sized = (r, m, l, g) => PIZZA_SIZES.map((name, i) => ({ name, price: [r, m, l, g][i] }));

const TIERS = {
  A: sized(110, 214, 333, 429),
  B: sized(138, 271, 371, 543),
  C: sized(162, 329, 510, 695),
  D: sized(186, 395, 548, 790),
  E: sized(214, 490, 619, 952),
};

const pizza = (name, tier, description = '', extra = {}) => ({
  id: slug(name),
  name,
  category: 'pizzas',
  veg: true,
  description,
  sizes: TIERS[tier],
  ...extra,
});

const item = (category, name, price, extra = {}) => ({
  id: slug(name),
  name,
  category,
  veg: true,
  description: '',
  price,
  ...extra,
});

const CHEESE = [EXTRAS.cheeseSlice];
const SCOOP = [EXTRAS.extraScoop];

// ---------- products ----------
export const PRODUCTS = [
  // A. PIZZAS
  pizza('Single Cheese Pizza', 'A'),
  pizza('Double Cheese Pizza', 'B'),
  pizza('Cheese & Mushroom', 'B'),
  pizza('Cheese & Corn', 'B'),
  pizza('Makhani Paneer Pizza', 'C'),
  pizza('Tandoori Paneer Pizza', 'C'),
  pizza('Achari Pizza', 'C'),
  pizza('Farm Fresh Pizza', 'C'),
  pizza('Delight Pizza', 'C'),
  pizza('Veg Hawaiian Pizza', 'D', 'Pineapple, Corn, Mushroom.'),
  pizza('Classic Pizza', 'D', 'Onion, Capsicum, Mushroom, Corn, Paneer.'),
  pizza('Black & White Pizza', 'D', 'Jalapeno, Black Olives, Corn, Extra Cheese.'),
  pizza('Spicy Paneer Pizza', 'D', 'Onion, Capsicum, Red Pepper, Paneer.', { spicy: true }),
  pizza('Chilly Pizza', 'D', 'Jalapeno, Red Pepper, Corn, Chilly Sauce.', { spicy: true }),
  pizza('Mix Veg. Pizza', 'E', 'Onions, Capsicum, Tomato, Mushroom, Corn, Black Olives, Jalapeno & Extra Cheese.'),
  pizza('Veg. Supreme Pizza', 'E', 'Capsicum, Mushroom, Corn, Paneer, Jalapeno, Red Pepper & Extra Cheese.'),
  pizza('Laden Pizza', 'E', 'Paneer, Tomato, Corn, Mushroom, Capsicum, Jalapeno, Tiki Crush, Extra Cheese.'),

  // B. MINI RANGE PIZZA'S
  ...[
    ['Soya', 59],
    ['Onion', 76],
    ['Capsicum', 86],
    ['Corn', 86],
    ['Pineapple', 86],
  ].map(([t, p]) =>
    item('mini-pizzas', `Mini Pizza – ${t}`, p, { subgroup: 'Mini Single Topping', description: `Mini pizza with ${t.toLowerCase()} topping.` })
  ),
  ...[
    ['Onion & Corn', 100],
    ['Soya & Corn', 100],
    ['Onion & Jalapenos', 100],
    ['Onion & Capsicum', 100],
    ['Paneer & Onion', 105],
    ['Paneer & Capsicum', 105],
    ['Jalapeno & Pineapple', 105],
  ].map(([t, p]) =>
    item('mini-pizzas', `Mini Pizza – ${t}`, p, { subgroup: 'Mini Double Toppings', description: `Mini pizza with ${t} toppings.` })
  ),
  item('mini-pizzas', 'Mini Pizza Combo', 300, { subgroup: 'Mini Pizza Combos', description: 'Combo — Any 4 Flavours.' }),
  // The conditions for this second combo price are not clear on the card.
  // Edit `name` / `description` below once the restaurant confirms what it covers.
  item('mini-pizzas', 'Mini Pizza Combo – Second Price', 362, {
    subgroup: 'Mini Pizza Combos',
    description: 'Combo offer — details to be confirmed by the restaurant.',
    id: 'mini-pizza-combo-second-price',
  }),

  // C. BURGERS (second price column on the card is not applied until its meaning is confirmed)
  item('burgers', 'Aloo Patty Burger', 39, { extras: CHEESE }),
  item('burgers', 'Veg Burger', 57, { extras: CHEESE }),
  item('burgers', 'Pub-ji Burger', 67, { extras: CHEESE }),
  item('burgers', 'Cheesy Burger', 71, { extras: CHEESE }),
  item('burgers', 'Juicy Corn Burger', 76, { extras: CHEESE }),
  item('burgers', 'Mexican Burger', 76, { extras: CHEESE }),
  item('burgers', 'Paneer Burger', 90, { extras: CHEESE }),
  item('burgers', 'Supreme Burger', 110, { extras: CHEESE }),

  // D. SANDWICHES
  item('sandwiches', 'Cold Sandwich', 76, { extras: CHEESE }),
  item('sandwiches', 'Grilled Sandwich', 86, { extras: CHEESE }),
  item('sandwiches', 'Spicy Grilled Sandwich', 95, { extras: CHEESE, spicy: true }),
  item('sandwiches', 'Cheesy Grilled Sandwich', 105, { extras: CHEESE }),
  item('sandwiches', 'Paneer Sandwich', 124, { extras: CHEESE }),

  // E. SALAD
  item('salad', 'Veg Salad', 114),
  item('salad', 'Paneer Salad', 129),
  item('salad', 'Mexican Salad', 129),

  // F. NEWLY LAUNCHED  (also listed under Fries, Snack's & More — same product id & price)
  item('fries-snacks', 'Popcorn Fries', 119, { alsoIn: ['newly-launched'] }),
  item('fries-snacks', 'Veggie Rings', 110, { alsoIn: ['newly-launched'] }),
  item('fries-snacks', 'Potato Cheese Balls', 110, { alsoIn: ['newly-launched'] }),
  item('fries-snacks', 'Pizza Samosa Bites', 110, { alsoIn: ['newly-launched'] }),

  // G. BREAD'S
  item('breads', 'Garlic Bread', 95),
  item('breads', 'Cheesy Sticks', 100),
  item('breads', 'Veg Loaded Garlic Bread', 124),
  item('breads', 'Laden Garlic Bread', 133),

  // H. DIP'S
  item('dips', 'Cheesy Dip', 29),
  item('dips', 'Spicy Dip', 29, { spicy: true }),
  item('dips', 'Mint Dip', 29),
  item('dips', 'Achari Dip', 29),
  item('dips', 'Makhni Dip', 29),
  item('dips', 'Tandoori Dip', 29),

  // I. PASTA'S
  item('pastas', 'Red Pasta', 110),
  item('pastas', 'White Pasta', 110),
  item('pastas', 'Tandoori Pasta', 119),
  item('pastas', 'Jumbo Pasta', 119),
  item('pastas', 'Makhni Pasta', 119),
  item('pastas', 'Sweet & Spicy Pasta', 129, { spicy: true }),

  // J. WRAP'S
  item('wraps', 'Aloo Tikki Wrap', 100),
  item('wraps', 'Cheesy Wrap', 110),
  item('wraps', 'Paneer Wrap', 119),
  item('wraps', 'Mexican Wrap', 119),

  // K. FRIES, SNACK'S & MORE (Popcorn Fries … Pizza Samosa Bites are defined above)
  item('fries-snacks', 'Salted Fries', 76),
  item('fries-snacks', 'Masala Fries', 86),
  item('fries-snacks', 'Peri-Peri Fries', 86, { spicy: true }),
  item('fries-snacks', 'Saucy Fries', 95),
  item('fries-snacks', 'Veg Pocket', 57),
  item('fries-snacks', 'Paneer Pocket', 67),
  item('fries-snacks', 'Veg Taco', 129),

  // L. DESSERT'S
  item('desserts', 'Ice Cream Vanilla (Chocolate)', 48, { emoji: '🍨' }),
  item('desserts', 'Ice Cream Vanilla (Strawberry)', 48, { emoji: '🍨' }),
  item('desserts', 'Ice Cream Vanilla (Butterscotch)', 48, { emoji: '🍨' }),
  item('desserts', 'Ice Cream Vanilla (Blue Berry)', 48, { emoji: '🍨' }),
  item('desserts', 'Ice Cream Vanilla', 43, { emoji: '🍨' }),
  item('desserts', 'Chocolava Cake', 81, { emoji: '🍫' }),
  item('desserts', 'Chocolava Cake with Ice Cream', 100, { emoji: '🍫' }),

  // M. SHAKE'S  (extras: SCOOP controls which shakes offer the extra-scoop add-on)
  item('shakes', 'Strawberry Shake', 100, { extras: SCOOP }),
  item('shakes', 'Chocolate Shake', 100, { extras: SCOOP }),
  item('shakes', 'Vanilla Shake', 100, { extras: SCOOP }),
  item('shakes', 'Oreo Shake', 100, { extras: SCOOP }),
  item('shakes', 'Butter Scotch Shake', 100, { extras: SCOOP }),
  item('shakes', 'Blue Berry Shake', 100, { extras: SCOOP }),
  item('shakes', 'Popcorn Caramel Shake', 124, { extras: SCOOP }),

  // N. MOJITO
  item('mojito', 'Mint Mojito', 100),
  item('mojito', 'Water Melon', 100, { id: 'water-melon-mojito', description: 'Water Melon mojito.' }),
  item('mojito', 'Blue Virgin Mojito', 100),

  // O. DRINK'S
  item('drinks', 'Hot Tea', 43, { description: 'Masala, Elaichi, Ginger.', emoji: '☕' }),
  item('drinks', 'Hot Coffee', 76, { emoji: '☕' }),
  item('drinks', 'Cold Coffee', 100),
  item('drinks', 'Fresh Lime Soda', 57),
  item('drinks', 'Coke/Pepsi/Sprite/Dew', 33, { id: 'cold-drink-bottle', description: 'Coke, Pepsi, Sprite or Dew — mention your choice on WhatsApp.' }),
  // MRP items: price stays null until the restaurant provides it.
  item('drinks', 'Fruit Drinks', null),
  item('drinks', 'Juice Can', null),
  item('drinks', 'Mineral Water', null),
];

// ---------- derived lookups (do not edit) ----------
export const PRODUCT_MAP = Object.fromEntries(PRODUCTS.map((p) => [p.id, p]));

export function productsForCategory(categoryId) {
  return PRODUCTS.filter((p) => p.category === categoryId || (p.alsoIn || []).includes(categoryId));
}

export const MENU_BY_CATEGORY = CATEGORIES.map((c) => ({ ...c, products: productsForCategory(c.id) }));

// Fail loudly in development if two products accidentally share an id.
if (new Set(PRODUCTS.map((p) => p.id)).size !== PRODUCTS.length) {
  throw new Error('menuData: duplicate product ids detected');
}
