// Central business settings. Edit here — no component changes needed.

export const BUSINESS = {
  // Neutral placeholder: replace with the restaurant's real name once confirmed.
  brandName: 'Pizza & Fast Food',
  brandTagline: 'Menu & Online Ordering',
  whatsappNumber: '917529064929', // country code 91 + 10-digit number, digits only
  whatsappDisplay: '7529064929',
  instagramHandle: '@digitalworld_tanda',
  instagramUrl: 'https://www.instagram.com/digitalworld_tanda/',
  supportCredit: 'Website & Digital Support: @digitalworld_tanda',
  copyright: '© 2026 All Rights Reserved.',
};

export const ORDER_RULES = {
  deliveryMinimum: 200, // ₹, checked on the food subtotal (excludes delivery charge)
  deliveryCharge: 20, // ₹ per order (not per item)
  lastDeliveryOrderTime: '10:30 PM',
  taxNote: 'Taxes extra — any applicable taxes will be confirmed by the restaurant.',
  // Opening hours were not supplied. Set a string here to display them; null hides them.
  openingHours: null,
  // 'free' accepts letters/digits (e.g. "A3"); set a number to restrict to 1..N.
  maxTableNumber: null,
};

export const ENQUIRY_MESSAGE = 'Hello! I would like to enquire about your menu.';
