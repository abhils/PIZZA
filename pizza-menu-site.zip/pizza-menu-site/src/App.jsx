import { useCallback, useState } from 'react';
import { ShoppingCart } from 'lucide-react';
import Header from './components/Header.jsx';
import HeroSection from './components/HeroSection.jsx';
import CategoryNavigation from './components/CategoryNavigation.jsx';
import MenuSection from './components/MenuSection.jsx';
import ShoppingCartDrawer from './components/ShoppingCart.jsx';
import CheckoutModal from './components/CheckoutModal.jsx';
import FloatingWhatsAppButton from './components/FloatingWhatsAppButton.jsx';
import InstagramSection from './components/InstagramSection.jsx';
import Footer from './components/Footer.jsx';
import Toast from './components/Toast.jsx';
import { MENU_BY_CATEGORY } from './data/menuData.js';
import { ORDER_RULES } from './data/config.js';
import { useCart } from './context/CartContext.jsx';
import { formatINR } from './utils/priceUtils.js';

const EMPTY_DETAILS = { name: '', mobile: '', address: '', landmark: '', area: '', city: '', instructions: '', table: '' };

export default function App() {
  const { isEmpty, count, totalsFor, showToast } = useCart();
  const [cartOpen, setCartOpen] = useState(false);
  const [checkoutOpen, setCheckoutOpen] = useState(false);
  // Lifted so going Back (or closing and re-opening) never wipes what the customer typed.
  const [details, setDetails] = useState(EMPTY_DETAILS);

  // Order Now / Checkout: with items → order-type popup; empty → helpful message + jump to menu.
  const startCheckout = useCallback(() => {
    if (isEmpty) {
      showToast('Your cart is empty — add something from the menu first.');
      document.getElementById('menu')?.scrollIntoView({ behavior: 'smooth' });
      return;
    }
    setCartOpen(false);
    setCheckoutOpen(true);
  }, [isEmpty, showToast]);

  const subtotal = totalsFor(null).subtotal;
  const barVisible = !isEmpty && !cartOpen && !checkoutOpen;

  return (
    <>
      <a href="#menu" className="sr-only focus:not-sr-only focus:fixed focus:left-3 focus:top-3 focus:z-[80] focus:rounded-lg focus:bg-white focus:px-4 focus:py-2 focus:font-bold">
        Skip to menu
      </a>
      <Header onOpenCart={() => setCartOpen(true)} onOrderNow={startCheckout} />

      <main>
        <HeroSection onOrderNow={startCheckout} />
        <CategoryNavigation />

        <div id="menu" className="paper scroll-mt-32">
          <div className="mx-auto max-w-7xl px-4 pb-6 pt-4">
            <div className="rounded-2xl border border-gold/70 bg-white/80 p-4 text-sm text-navy">
              <p className="font-bold">Good to know</p>
              <ul className="mt-1 list-inside list-disc space-y-0.5 text-ink/80">
                <li>
                  Home delivery: minimum food order ₹{ORDER_RULES.deliveryMinimum}, delivery charge ₹{ORDER_RULES.deliveryCharge} per order.
                </li>
                <li>Last Home Delivery Order: {ORDER_RULES.lastDeliveryOrderTime}</li>
                <li>Taxes extra. Orders are placed by sending a WhatsApp message — the restaurant confirms the final bill.</li>
              </ul>
            </div>
            {MENU_BY_CATEGORY.map((c, i) => (
              <MenuSection key={c.id} category={c} products={c.products} index={i} />
            ))}
          </div>
        </div>

        <InstagramSection />
      </main>

      <Footer />

      {/* Sticky mobile cart bar */}
      {barVisible && (
        <div className="fixed inset-x-0 bottom-0 z-30 border-t border-gold bg-ivory/95 p-3 pb-[max(0.75rem,env(safe-area-inset-bottom))] backdrop-blur sm:hidden">
          <button
            type="button"
            onClick={() => setCartOpen(true)}
            className="flex h-14 w-full items-center justify-between rounded-2xl bg-brand-red px-5 text-white shadow-lg"
          >
            <span className="flex items-center gap-2 text-sm font-bold">
              <ShoppingCart className="h-5 w-5" /> View Cart · {count} item{count === 1 ? '' : 's'}
            </span>
            <span className="text-base font-extrabold">{formatINR(subtotal)}</span>
          </button>
        </div>
      )}

      <FloatingWhatsAppButton raised={barVisible} />
      <Toast raised={barVisible} />

      {cartOpen && <ShoppingCartDrawer onClose={() => setCartOpen(false)} onCheckout={startCheckout} />}
      {checkoutOpen && (
        <CheckoutModal
          details={details}
          setDetails={setDetails}
          onClose={() => setCheckoutOpen(false)}
          onEditOrder={() => {
            setCheckoutOpen(false);
            setCartOpen(true);
          }}
        />
      )}
    </>
  );
}
