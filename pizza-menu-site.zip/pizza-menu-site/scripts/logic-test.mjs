// Dependency-free checks for menu data, cart rules, totals, validation and the WhatsApp message.
// Run: npm run test:logic
import assert from 'node:assert/strict';
import { PRODUCTS, CATEGORIES, productsForCategory, PRODUCT_MAP } from '../src/data/menuData.js';
import { cartReducer, makeKey } from '../src/utils/cartUtils.js';
import { resolveLine, calcTotals, formatINR } from '../src/utils/priceUtils.js';
import { validateDelivery, validateDineIn, normaliseMobile } from '../src/utils/validationUtils.js';
import { buildOrderMessage, buildOrderUrl } from '../src/utils/whatsappUtils.js';

let passed = 0;
const t = (name, fn) => { fn(); passed++; console.log('  ✓', name); };
const resolve = (cart) => cart.map(resolveLine).filter(Boolean);

t('15 categories present', () => assert.equal(CATEGORIES.length, 15));
t('every category has products', () => CATEGORIES.forEach((c) => assert.ok(productsForCategory(c.id).length > 0, c.id)));
t('17 pizzas, each with 4 sizes in order', () => {
  const pz = PRODUCTS.filter((p) => p.category === 'pizzas');
  assert.equal(pz.length, 17);
  pz.forEach((p) => assert.deepEqual(p.sizes.map((s) => s.name), ['Regular', 'Medium', 'Large', 'Giant']));
});
t('spot-check pizza prices', () => {
  assert.deepEqual(PRODUCT_MAP['single-cheese-pizza'].sizes.map((s) => s.price), [110, 214, 333, 429]);
  assert.deepEqual(PRODUCT_MAP['laden-pizza'].sizes.map((s) => s.price), [214, 490, 619, 952]);
  assert.deepEqual(PRODUCT_MAP['veg-hawaiian-pizza'].sizes.map((s) => s.price), [186, 395, 548, 790]);
});
t('shared products appear in both categories with one id/price', () => {
  const nl = productsForCategory('newly-launched').map((p) => p.id);
  const fr = productsForCategory('fries-snacks').map((p) => p.id);
  ['popcorn-fries', 'veggie-rings', 'potato-cheese-balls', 'pizza-samosa-bites'].forEach((id) => {
    assert.ok(nl.includes(id) && fr.includes(id));
  });
  assert.equal(PRODUCT_MAP['popcorn-fries'].price, 119);
});
t('MRP items have null price (not 0)', () => {
  ['fruit-drinks', 'juice-can', 'mineral-water'].forEach((id) => assert.equal(PRODUCT_MAP[id].price, null));
});
t('item counts per category', () => {
  const n = (c) => productsForCategory(c).length;
  assert.equal(n('burgers'), 8); assert.equal(n('sandwiches'), 5); assert.equal(n('salad'), 3);
  assert.equal(n('newly-launched'), 4); assert.equal(n('breads'), 4); assert.equal(n('dips'), 6);
  assert.equal(n('pastas'), 6); assert.equal(n('wraps'), 4); assert.equal(n('fries-snacks'), 11);
  assert.equal(n('desserts'), 7); assert.equal(n('shakes'), 7); assert.equal(n('mojito'), 3);
  assert.equal(n('drinks'), 8); assert.equal(n('mini-pizzas'), 14);
});

t('pizza cannot be added without a size', () => {
  assert.equal(cartReducer([], { type: 'ADD', productId: 'laden-pizza', size: null }).length, 0);
});
t('different sizes of same pizza are separate lines', () => {
  let c = cartReducer([], { type: 'ADD', productId: 'laden-pizza', size: 'Regular' });
  c = cartReducer(c, { type: 'ADD', productId: 'laden-pizza', size: 'Large' });
  c = cartReducer(c, { type: 'ADD', productId: 'laden-pizza', size: 'Large' });
  assert.equal(c.length, 2);
  assert.equal(c.find((l) => l.size === 'Large').qty, 2);
});
t('extras create separate lines and are priced', () => {
  let c = cartReducer([], { type: 'ADD', productId: 'veg-burger' });
  c = cartReducer(c, { type: 'ADD', productId: 'veg-burger', extraIds: ['cheese-slice'] });
  assert.equal(c.length, 2);
  const lines = resolve(c);
  assert.equal(lines.find((l) => l.extras.length).unitPrice, 57 + 11);
});
t('invalid extras are ignored', () => {
  const c = cartReducer([], { type: 'ADD', productId: 'veg-salad', extraIds: ['extra-scoop'] });
  assert.deepEqual(c[0].extraIds, []);
});
t('inc / dec / remove', () => {
  let c = cartReducer([], { type: 'ADD', productId: 'masala-fries' });
  const key = c[0].key;
  c = cartReducer(c, { type: 'INC', key }); assert.equal(c[0].qty, 2);
  c = cartReducer(c, { type: 'DEC', key }); assert.equal(c[0].qty, 1);
  c = cartReducer(c, { type: 'DEC', key }); assert.equal(c.length, 0);
});

const cartOf = (...adds) => adds.reduce((c, a) => cartReducer(c, { type: 'ADD', ...a }), []);

t('delivery charge applied once, not per quantity', () => {
  const lines = resolve(cartOf({ productId: 'cheese-and-corn', size: 'Regular', qty: 3 }));
  const tot = calcTotals(lines, 'delivery');
  assert.equal(tot.subtotal, 138 * 3);
  assert.equal(tot.deliveryCharge, 20);
  assert.equal(tot.knownTotal, 414 + 20);
});
t('dine-in has no delivery charge or minimum', () => {
  const tot = calcTotals(resolve(cartOf({ productId: 'aloo-patty-burger' })), 'dinein');
  assert.equal(tot.deliveryCharge, 0); assert.equal(tot.meetsMinimum, true);
});
t('delivery minimum enforced on food subtotal (excluding delivery fee)', () => {
  const low = calcTotals(resolve(cartOf({ productId: 'salted-fries' })), 'delivery'); // 76
  assert.equal(low.meetsMinimum, false); assert.equal(low.shortBy, 124);
  const exact = calcTotals(resolve(cartOf({ productId: 'cold-coffee', qty: 2 })), 'delivery'); // 200
  assert.equal(exact.meetsMinimum, true);
  const nearly = calcTotals(resolve(cartOf({ productId: 'popcorn-fries' }, { productId: 'cold-drink-bottle', qty: 2 })), 'delivery'); // 119+66=185
  assert.equal(nearly.meetsMinimum, false); assert.equal(nearly.shortBy, 15);
});
t('switching order type recalculates', () => {
  const lines = resolve(cartOf({ productId: 'laden-pizza', size: 'Giant' }));
  assert.equal(calcTotals(lines, 'delivery').knownTotal, 972);
  assert.equal(calcTotals(lines, 'dinein').knownTotal, 952);
});
t('MRP items are flagged and not counted as ₹0 prices', () => {
  const lines = resolve(cartOf({ productId: 'mineral-water' }, { productId: 'hot-coffee' }));
  const tot = calcTotals(lines, 'dinein');
  assert.equal(tot.hasUnpriced, true); assert.equal(tot.subtotal, 76);
  assert.equal(lines.find((l) => l.productId === 'mineral-water').unitPrice, null);
});
t('INR formatting', () => { assert.equal(formatINR(1234), '₹1,234'); assert.equal(formatINR(100000), '₹1,00,000'); });

t('mobile validation', () => {
  assert.equal(normaliseMobile('98765 43210'), '9876543210');
  assert.equal(normaliseMobile('+91 98765-43210'), '9876543210');
  assert.equal(normaliseMobile('1234567890'), null);
  assert.equal(normaliseMobile('98765'), null);
});
t('delivery validation requires all fields', () => {
  assert.ok(Object.keys(validateDelivery({})).length >= 5);
  assert.deepEqual(validateDelivery({ name: 'Asha K', mobile: '9876543210', address: 'Near temple, Main Market', landmark: 'House 4', area: 'Market', city: 'Tanda' }), {});
});
t('dine-in requires table, mobile optional, no address', () => {
  assert.ok(validateDineIn({ name: 'Ravi', table: '' }).table);
  assert.deepEqual(validateDineIn({ name: 'Ravi', table: '5' }), {});
  assert.ok(validateDineIn({ name: 'Ravi', table: '5', mobile: '123' }).mobile);
});

t('WhatsApp delivery message + URL', () => {
  const lines = resolve(cartOf({ productId: 'laden-pizza', size: 'Large', qty: 2 }, { productId: 'oreo-shake', extraIds: ['extra-scoop'] }));
  const totals = calcTotals(lines, 'delivery');
  const details = { name: 'Asha K', mobile: '98765 43210', address: 'Street 4, Main Market', landmark: 'Near school', area: 'Old Town', city: 'Tanda', instructions: 'Call at gate' };
  const msg = buildOrderMessage({ orderType: 'delivery', details, lines, totals });
  assert.match(msg, /ORDER TYPE: HOME DELIVERY/);
  assert.match(msg, /1\. Laden Pizza — Large/);
  assert.match(msg, /Quantity: 2/); assert.match(msg, /Unit Price: ₹619/); assert.match(msg, /Total: ₹1,238/);
  assert.match(msg, /Extras: Extra Ice Cream Scoop \(\+₹30\)/);
  assert.match(msg, /Delivery Charge: ₹20/);
  assert.match(msg, /Known Total: ₹1,388/); // 1238 + 130 + 20
  assert.match(msg, /Mobile: 9876543210/);
  assert.match(msg, /Delivery Instructions: Call at gate/);
  const url = buildOrderUrl({ orderType: 'delivery', details, lines, totals });
  assert.ok(url.startsWith('https://wa.me/917529064929?text='));
  assert.equal(decodeURIComponent(url.split('?text=')[1]), msg);
});
t('WhatsApp dine-in message', () => {
  const lines = resolve(cartOf({ productId: 'single-cheese-pizza', size: 'Regular' }, { productId: 'juice-can' }));
  const totals = calcTotals(lines, 'dinein');
  const msg = buildOrderMessage({ orderType: 'dinein', details: { name: 'Ravi', table: '7', mobile: '' }, lines, totals });
  assert.match(msg, /ORDER TYPE: DINE-IN/); assert.match(msg, /Table Number: 7/);
  assert.match(msg, /Mobile: Not Provided/); assert.match(msg, /Delivery Charge: ₹0/);
  assert.match(msg, /MRP — to be confirmed/); assert.doesNotMatch(msg, /DELIVERY ADDRESS/);
});

console.log(`\n${passed} checks passed`);
