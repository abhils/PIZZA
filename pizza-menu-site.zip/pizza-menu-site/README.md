# Pizza Menu Website — WhatsApp Ordering

React + Vite + Tailwind CSS (v4) restaurant menu with a working cart, a Home Delivery / Dine-In checkout, and
WhatsApp ordering to **+91 75290 64929**. Instagram: **@digitalworld_tanda**.

No accounts, no payments, no backend. Orders are a pre-filled WhatsApp message — the customer must press **Send**,
and the restaurant confirms the bill.

## Run it

```bash
npm install
npm run dev        # http://localhost:5173
npm run build      # production files in /dist
npm run preview    # test the production build locally
npm run test:logic # prices, cart, totals, validation, WhatsApp message (no dependencies needed)
```

Requires Node 20.19+ (needed by Vite 7).

## Deploy (static site)

Upload the `dist/` folder, or connect the repo, on Netlify / Vercel / Cloudflare Pages / GitHub Pages
(build command `npm run build`, output directory `dist`). No server settings are needed.
Once you have the final domain, add a `sitemap.xml` and a `Sitemap:` line in `public/robots.txt`.

## What the owner edits (no component code)

| Change | File |
| --- | --- |
| Prices, items, descriptions, veg/spicy flags, categories, notes | `src/data/menuData.js` |
| WhatsApp number, Instagram, brand name, delivery minimum/charge, last delivery time, opening hours | `src/data/config.js` |
| Colours | `@theme` block at the top of `src/index.css` |

**Photos:** put image files in `public/images/` and set `image: '/images/laden-pizza.webp'` on a product.
Products without a photo show a clean illustration (vector pizza for pizzas, emoji tiles for the rest).
Use ~800×600 images (4:3), WebP, under ~100 KB each.

**MRP items** (Fruit Drinks, Juice Can, Mineral Water): set `price: null` → set a number when known, e.g. `price: 20`.
Until then they are flagged "Price to be confirmed by restaurant" and excluded from totals.

**Restaurant name:** the brief did not give a legible name, so the brand shows the neutral text
"Pizza & Fast Food". Change `brandName` in `config.js` (and replace `BrandMark` in `src/components/icons.jsx` with a logo).

## Please confirm with the restaurant

These were not clear from the brief, so they were **not guessed**:

1. **Burger second price column** — not applied. Add a size/price structure in `menuData.js` once its meaning is known.
2. **"Mini Pizza Combo – Second Price" (₹362)** — shown with a placeholder description; edit the name/description to match the card.
3. **Salad veg patty ₹29, extra cheese dip ₹11, extra garlic bread ₹29** — shown as notes only, not auto-added.
4. **Which shakes offer the extra scoop (₹30)** — currently all 7; remove `extras: SCOOP` from any that don't.
5. **Cheese slice add-on (₹11)** — currently offered on all burgers and sandwiches.
6. **Veg / Spicy markers** — all items are marked Veg; "Spicy" is set only on items whose names say so
   (Spicy Paneer Pizza, Chilly Pizza, Spicy Grilled Sandwich, Spicy Dip, Sweet & Spicy Pasta, Peri-Peri Fries).
   Compare with the printed card and adjust `veg` / `spicy` flags.
7. **Opening hours** — none supplied; set `openingHours` in `config.js` to display them.

## How checkout works

Cart → **Order Now / Checkout** → popup *"How Would You Like to Receive Your Order?"* → Home Delivery form
(name, 10-digit mobile, address, street/landmark, area, city/village, optional instructions) **or** Dine-In form
(name, table number required, optional mobile) → order summary → **Confirm & Order on WhatsApp**.

- Delivery: food subtotal must be ≥ ₹200; ₹20 charged once per order. Dine-in: no charge, no minimum.
- Taxes are shown as "Extra — to be confirmed" (no percentage is invented).
- Totals are always recomputed from `menuData.js`; the cart in local storage only stores product id, size, extras, quantity.
- The cart is kept after WhatsApp opens; the page never claims the order is confirmed.
